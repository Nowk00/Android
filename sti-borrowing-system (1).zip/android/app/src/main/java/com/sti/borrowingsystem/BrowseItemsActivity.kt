package com.sti.borrowingsystem

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.sti.borrowingsystem.adapters.ItemsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityBrowseItemsBinding
import com.sti.borrowingsystem.models.Item
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class BrowseItemsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBrowseItemsBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var itemsAdapter: ItemsAdapter
    private var allItems = listOf<Item>()
    private var filteredItems = listOf<Item>()
    private val selectedItemIds = mutableSetOf<Int>()
    private var isSelectionMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBrowseItemsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        isSelectionMode = intent.getBooleanExtra("selection_mode", false)
        
        setupToolbar()
        setupRecyclerView()
        setupSearch()
        setupFilters()
        setupSwipeRefresh()
        loadItems()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = if (isSelectionMode) "Select Items" else "Browse Items"
        
        if (isSelectionMode) {
            binding.btnConfirmSelection.visibility = View.VISIBLE
            binding.btnConfirmSelection.setOnClickListener {
                confirmSelection()
            }
        }
    }

    private fun setupRecyclerView() {
        itemsAdapter = ItemsAdapter(
            isSelectionMode = isSelectionMode,
            onItemClick = { item ->
                if (isSelectionMode) {
                    toggleItemSelection(item)
                } else {
                    showItemDetail(item)
                }
            },
            onItemSelected = { item, isSelected ->
                if (isSelected) {
                    selectedItemIds.add(item.item_id)
                } else {
                    selectedItemIds.remove(item.item_id)
                }
                updateSelectionUI()
            }
        )
        
        binding.rvItems.apply {
            layoutManager = GridLayoutManager(this@BrowseItemsActivity, 2)
            adapter = itemsAdapter
        }
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                filterItems()
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterItems()
                return true
            }
        })
    }

    private fun setupFilters() {
        // Category filters
        val categories = listOf("All", "Electronics", "Laboratory", "Sports", "Furniture", "Tools")
        categories.forEach { category ->
            val chip = Chip(this)
            chip.text = category
            chip.isCheckable = true
            chip.isChecked = category == "All"
            chip.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    // Uncheck other chips
                    for (i in 0 until binding.chipGroupCategories.childCount) {
                        val otherChip = binding.chipGroupCategories.getChildAt(i) as Chip
                        if (otherChip != chip) {
                            otherChip.isChecked = false
                        }
                    }
                    filterItems()
                }
            }
            binding.chipGroupCategories.addView(chip)
        }

        // Condition filters
        val conditions = listOf("All", "Excellent", "Good", "Fair")
        conditions.forEach { condition ->
            val chip = Chip(this)
            chip.text = condition
            chip.isCheckable = true
            chip.isChecked = condition == "All"
            chip.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    // Uncheck other chips
                    for (i in 0 until binding.chipGroupConditions.childCount) {
                        val otherChip = binding.chipGroupConditions.getChildAt(i) as Chip
                        if (otherChip != chip) {
                            otherChip.isChecked = false
                        }
                    }
                    filterItems()
                }
            }
            binding.chipGroupConditions.addView(chip)
        }

        // Available only switch
        binding.switchAvailableOnly.setOnCheckedChangeListener { _, _ ->
            filterItems()
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadItems()
        }
    }

    private fun loadItems() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(this, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.itemService.getItems(
                    token = token,
                    availableOnly = binding.switchAvailableOnly.isChecked
                )

                if (response.success) {
                    allItems = response.data
                    filterItems()
                } else {
                    Toast.makeText(this@BrowseItemsActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@BrowseItemsActivity, "Failed to load items: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun filterItems() {
        val query = binding.searchView.query.toString().lowercase()
        val selectedCategory = getSelectedChip(binding.chipGroupCategories)
        val selectedCondition = getSelectedChip(binding.chipGroupConditions)
        val availableOnly = binding.switchAvailableOnly.isChecked

        filteredItems = allItems.filter { item ->
            val matchesQuery = query.isEmpty() || 
                item.item_name.lowercase().contains(query) ||
                item.description?.lowercase()?.contains(query) == true

            val matchesCategory = selectedCategory == "All" || 
                item.category_name?.equals(selectedCategory, ignoreCase = true) == true

            val matchesCondition = selectedCondition == "All" || 
                item.condition_status.equals(selectedCondition, ignoreCase = true)

            val matchesAvailability = !availableOnly || item.quantity_available > 0

            matchesQuery && matchesCategory && matchesCondition && matchesAvailability
        }

        itemsAdapter.updateItems(filteredItems)
        updateEmptyState()
    }

    private fun getSelectedChip(chipGroup: com.google.android.material.chip.ChipGroup): String {
        for (i in 0 until chipGroup.childCount) {
            val chip = chipGroup.getChildAt(i) as Chip
            if (chip.isChecked) {
                return chip.text.toString()
            }
        }
        return "All"
    }

    private fun updateEmptyState() {
        if (filteredItems.isEmpty()) {
            binding.tvEmptyItems.visibility = View.VISIBLE
            binding.rvItems.visibility = View.GONE
            
            binding.tvEmptyItems.text = if (allItems.isEmpty()) {
                "No items available"
            } else {
                "No items match your filters"
            }
        } else {
            binding.tvEmptyItems.visibility = View.GONE
            binding.rvItems.visibility = View.VISIBLE
        }
    }

    private fun toggleItemSelection(item: Item) {
        if (selectedItemIds.contains(item.item_id)) {
            selectedItemIds.remove(item.item_id)
        } else {
            selectedItemIds.add(item.item_id)
        }
        itemsAdapter.notifyDataSetChanged()
        updateSelectionUI()
    }

    private fun updateSelectionUI() {
        if (isSelectionMode) {
            binding.btnConfirmSelection.text = "Select ${selectedItemIds.size} Items"
            binding.btnConfirmSelection.isEnabled = selectedItemIds.isNotEmpty()
        }
    }

    private fun confirmSelection() {
        val intent = Intent()
        intent.putIntegerArrayListExtra("selected_items", ArrayList(selectedItemIds))
        setResult(RESULT_OK, intent)
        finish()
    }

    private fun showItemDetail(item: Item) {
        val intent = Intent(this, ItemDetailActivity::class.java)
        intent.putExtra("item_id", item.item_id)
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
