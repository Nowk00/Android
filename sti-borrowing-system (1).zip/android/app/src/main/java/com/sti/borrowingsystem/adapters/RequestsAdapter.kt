package com.sti.borrowingsystem.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textview.MaterialTextView
import com.sti.borrowingsystem.R
import com.sti.borrowingsystem.models.BorrowingRequest
import java.text.SimpleDateFormat
import java.util.*

class RequestsAdapter(
    private val onRequestClick: (BorrowingRequest) -> Unit
) : RecyclerView.Adapter<RequestsAdapter.RequestViewHolder>() {
    
    private var requests = listOf<BorrowingRequest>()
    
    fun updateRequests(newRequests: List<BorrowingRequest>) {
        requests = newRequests
        notifyDataSetChanged()
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RequestViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_request, parent, false)
        return RequestViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: RequestViewHolder, position: Int) {
        holder.bind(requests[position])
    }
    
    override fun getItemCount() = requests.size
    
    inner class RequestViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val cardRequest: MaterialCardView = itemView.findViewById(R.id.card_request)
        private val tvRequestId: MaterialTextView = itemView.findViewById(R.id.tv_request_id)
        private val tvSubject: MaterialTextView = itemView.findViewById(R.id.tv_subject)
        private val tvRequester: MaterialTextView = itemView.findViewById(R.id.tv_requester)
        private val tvItems: MaterialTextView = itemView.findViewById(R.id.tv_items)
        private val tvDate: MaterialTextView = itemView.findViewById(R.id.tv_date)
        private val tvStatus: MaterialTextView = itemView.findViewById(R.id.tv_status)
        
        fun bind(request: BorrowingRequest) {
            tvRequestId.text = "#${request.request_id.toString().padStart(4, '0')}"
            tvSubject.text = request.subject
            
            // Show requester name if available (for custodians/admins)
            if (!request.first_name.isNullOrEmpty()) {
                tvRequester.text = "${request.first_name} ${request.last_name}"
                tvRequester.visibility = View.VISIBLE
            } else {
                tvRequester.visibility = View.GONE
            }
            
            tvItems.text = request.items_list ?: "No items"
            
            // Format date
            try {
                val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val outputFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                val date = inputFormat.parse(request.created_at)
                tvDate.text = outputFormat.format(date ?: Date())
            } catch (e: Exception) {
                tvDate.text = request.created_at
            }
            
            // Set status with color
            tvStatus.text = request.status
            val statusColor = when (request.status.lowercase()) {
                "pending" -> R.color.status_pending
                "approved" -> R.color.status_approved
                "rejected" -> R.color.status_rejected
                "completed" -> R.color.status_completed
                "returned" -> R.color.status_returned
                else -> R.color.status_default
            }
            tvStatus.setTextColor(ContextCompat.getColor(itemView.context, statusColor))
            
            cardRequest.setOnClickListener {
                onRequestClick(request)
            }
        }
    }
}
