package com.sti.borrowingsystem.models

import com.google.gson.annotations.SerializedName

// API Response wrapper
data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T,
    val timestamp: String
)

// Auth Models
data class LoginRequest(
    val action: String,
    val id_number: String,
    val password: String
)

data class LoginResponse(
    val token: String,
    val user: User
)

data class RegisterRequest(
    val action: String,
    val student_number: String,
    val last_name: String,
    val first_name: String,
    val email: String,
    val password: String
)

data class RegisterResponse(
    val id_number: String,
    val message: String
)

// User Model
data class User(
    val user_id: Int,
    val id_number: String,
    val first_name: String,
    val last_name: String,
    val email: String,
    val user_type: String
)

// Request Models
data class BorrowingRequest(
    val request_id: Int,
    val subject: String,
    val description: String?,
    val scheduled_date: String,
    val status: String,
    val created_at: String,
    val items_list: String?,
    val item_count: Int,
    val first_name: String? = null,
    val last_name: String? = null
)

data class BorrowingRequestDetail(
    val request_id: Int,
    val subject: String,
    val description: String?,
    val scheduled_date: String,
    val status: String,
    val created_at: String,
    val return_date: String?,
    val requester_first_name: String,
    val requester_last_name: String,
    val requester_id_number: String,
    val approver_first_name: String?,
    val approver_last_name: String?,
    val items: List<RequestItem>
)

data class RequestItem(
    val request_item_id: Int,
    val item_id: Int,
    val item_name: String,
    val item_code: String,
    val description: String?,
    val quantity_requested: Int,
    val quantity_returned: Int,
    val item_status: String,
    val issued_date: String?,
    val returned_date: String?
)

data class CreateRequestRequest(
    val subject: String,
    val description: String?,
    val scheduled_date: String,
    val items: List<RequestItemInput>
)

data class RequestItemInput(
    val item_id: Int,
    val quantity: Int
)

data class CreateRequestResponse(
    val request_id: Int,
    val formatted_id: String
)

// Item Models
data class Item(
    val item_id: Int,
    val item_code: String,
    val item_name: String,
    val description: String?,
    val quantity: Int,
    val available_quantity: Int,
    val condition_status: String,
    val borrowed_qty: Int
)

// Dashboard Models
data class DashboardData(
    val user_stats: UserStats? = null,
    val system_stats: SystemStats? = null,
    val recent_requests: List<BorrowingRequest>,
    val notifications: List<Notification>
)

data class UserStats(
    val total_requests: Int,
    val pending_requests: Int,
    val approved_requests: Int,
    val completed_requests: Int
)

data class SystemStats(
    val total_requests: Int,
    val pending_requests: Int,
    val approved_requests: Int,
    val completed_requests: Int
)

data class Notification(
    val notification_id: Int,
    val message: String,
    val notification_type: String,
    val created_at: String,
    val is_read: Boolean
)
