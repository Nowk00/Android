package com.sti.borrowingsystem.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.sti.borrowingsystem.CreateRequestActivity
import com.sti.borrowingsystem.R
import com.sti.borrowingsystem.adapters.RequestsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class RequestsFragment : Fragment() {
    
    private lateinit var sessionManager: SessionManager
    private lateinit var requestsAdapter: RequestsAdapter
    
    // Views
    private lateinit var rvRequests: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var fabCreateRequest: FloatingActionButton
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_requests, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        sessionManager = SessionManager(requireContext())
        initViews(view)
        setupRecyclerView()
        setupSwipeRefresh()
        loadRequests()
    }
    
    private fun initViews(view: View) {
        rvRequests = view.findViewById(R.id.rv_requests)
        swipeRefresh = view.findViewById(R.id.swipe_refresh)
        fabCreateRequest = view.findViewById(R.id.fab_create_request)
        
        // Show FAB only for borrowers
        val user = sessionManager.getUser()
        if (user?.user_type == "Borrower") {
            fabCreateRequest.visibility = View.VISIBLE
            fabCreateRequest.setOnClickListener {
                startActivity(Intent(context, CreateRequestActivity::class.java))
            }
        } else {
            fabCreateRequest.visibility = View.GONE
        }
    }
    
    private fun setupRecyclerView() {
        requestsAdapter = RequestsAdapter { request ->
            // Handle request click - navigate to detail
            // TODO: Implement navigation to request detail
        }
        
        rvRequests.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = requestsAdapter
        }
    }
    
    private fun setupSwipeRefresh() {
        swipeRefresh.setOnRefreshListener {
            loadRequests()
        }
    }
    
    private fun loadRequests() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(context, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val response = ApiClient.requestService.getRequests(token)
                
                if (response.success) {
                    requestsAdapter.updateRequests(response.data)
                } else {
                    Toast.makeText(context, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load requests: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                swipeRefresh.isRefreshing = false
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        loadRequests() // Refresh when returning to fragment
    }
}
