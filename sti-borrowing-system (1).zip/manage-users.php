<?php
require_once 'config/functions.php';
requireUserType(['Administrator']);

$user_info = getUserInfo($_SESSION['user_id']);

$success_message = getSuccessMessage();
$error_message = getErrorMessage();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'add_user':
                $student_number = sanitizeInput($_POST['student_number']);
                $last_name = sanitizeInput($_POST['last_name']);
                $first_name = sanitizeInput($_POST['first_name']);
                $email = sanitizeInput($_POST['email']);
                $password = $_POST['password'];
                $user_type = $_POST['user_type'];
                $department = sanitizeInput($_POST['department'] ?? '');
                
                // Validation
                if (!validateStudentNumber($student_number)) {
                    throw new Exception('Student number must be exactly 6 digits.');
                }
                
                if (!validateEmail($email)) {
                    throw new Exception('Please enter a valid email address.');
                }
                
                if (!validatePassword($password)) {
                    throw new Exception('Password must be at least 6 characters long.');
                }
                
                $id_number = generateIdNumber($last_name, $student_number);
                
                if (userExists($id_number, $email)) {
                    throw new Exception('User with this ID number or email already exists.');
                }
                
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("
                    INSERT INTO users (id_number, first_name, last_name, email, password, user_type, department) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$id_number, $first_name, $last_name, $email, $hashed_password, $user_type, $department]);
                
                $new_user_id = $pdo->lastInsertId();
                
                logActivity($_SESSION['user_id'], 'Add User', "Added new user: $first_name $last_name ($id_number)");
                createNotification($new_user_id, 'Welcome to STI Borrowing System!', 'Success');
                
                setSuccessMessage("User '$first_name $last_name' has been added successfully! ID Number: $id_number");
                break;
                
            case 'edit_user':
                $user_id = (int)$_POST['user_id'];
                $first_name = sanitizeInput($_POST['first_name']);
                $last_name = sanitizeInput($_POST['last_name']);
                $email = sanitizeInput($_POST['email']);
                $user_type = $_POST['user_type'];
                $department = sanitizeInput($_POST['department'] ?? '');
                
                if (!validateEmail($email)) {
                    throw new Exception('Please enter a valid email address.');
                }
                
                // Check if email is already used by another user
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ? AND archived = FALSE");
                $stmt->execute([$email, $user_id]);
                if ($stmt->fetchColumn() > 0) {
                    throw new Exception('Email address is already in use by another user.');
                }
                
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, user_type = ?, department = ?
                    WHERE user_id = ?
                ");
                $stmt->execute([$first_name, $last_name, $email, $user_type, $department, $user_id]);
                
                logActivity($_SESSION['user_id'], 'Edit User', "Updated user: $first_name $last_name (ID: $user_id)");
                setSuccessMessage("User information has been updated successfully!");
                break;
                
            case 'reset_password':
                $user_id = (int)$_POST['user_id'];
                $new_password = $_POST['new_password'];
                
                if (!validatePassword($new_password)) {
                    throw new Exception('Password must be at least 6 characters long.');
                }
                
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $stmt->execute([$hashed_password, $user_id]);
                
                // Get user info for notification
                $user_data = getUserInfo($user_id);
                
                logActivity($_SESSION['user_id'], 'Reset Password', "Reset password for user: {$user_data['first_name']} {$user_data['last_name']}");
                createNotification($user_id, 'Your password has been reset by an administrator.', 'Warning');
                
                setSuccessMessage("Password has been reset successfully!");
                break;
                
            case 'archive_user':
                $user_id = (int)$_POST['user_id'];
                
                // Prevent archiving the current user
                if ($user_id == $_SESSION['user_id']) {
                    throw new Exception('You cannot archive your own account.');
                }
                
                // Check for active requests
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM borrowing_requests 
                    WHERE requester_id = ? AND status IN ('Pending', 'Approved') AND archived = FALSE
                ");
                $stmt->execute([$user_id]);
                $active_requests = $stmt->fetchColumn();
                
                if ($active_requests > 0) {
                    throw new Exception('Cannot archive user with active borrowing requests.');
                }
                
                $stmt = $pdo->prepare("UPDATE users SET archived = TRUE WHERE user_id = ?");
                $stmt->execute([$user_id]);
                
                // Get user info for logging
                $user_data = getUserInfo($user_id);
                
                logActivity($_SESSION['user_id'], 'Archive User', "Archived user: {$user_data['first_name']} {$user_data['last_name']}");
                setSuccessMessage("User has been archived successfully!");
                break;
                
            case 'restore_user':
                $user_id = (int)$_POST['user_id'];
                
                $stmt = $pdo->prepare("UPDATE users SET archived = FALSE WHERE user_id = ?");
                $stmt->execute([$user_id]);
                
                logActivity($_SESSION['user_id'], 'Restore User', "Restored user (ID: $user_id)");
                setSuccessMessage("User has been restored successfully!");
                break;
        }
        
        header('Location: manage-users.php');
        exit();
        
    } catch (Exception $e) {
        setErrorMessage($e->getMessage());
        header('Location: manage-users.php');
        exit();
    } catch (PDOException $e) {
        setErrorMessage('Database operation failed. Please try again.');
        error_log("Manage users error: " . $e->getMessage());
        header('Location: manage-users.php');
        exit();
    }
}

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$user_type_filter = $_GET['user_type'] ?? 'all';
$status_filter = $_GET['status'] ?? 'active';

// Build query
$where_conditions = [];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(first_name LIKE ? OR last_name LIKE ? OR id_number LIKE ? OR email LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
}

if ($user_type_filter !== 'all') {
    $where_conditions[] = "user_type = ?";
    $params[] = $user_type_filter;
}

if ($status_filter === 'active') {
    $where_conditions[] = "archived = FALSE";
} elseif ($status_filter === 'archived') {
    $where_conditions[] = "archived = TRUE";
}

$where_clause = empty($where_conditions) ? '1=1' : implode(' AND ', $where_conditions);

try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               COUNT(br.request_id) as total_requests,
               COUNT(CASE WHEN br.status = 'Pending' THEN 1 END) as pending_requests
        FROM users u
        LEFT JOIN borrowing_requests br ON u.user_id = br.requester_id AND br.archived = FALSE
        WHERE $where_clause
        GROUP BY u.user_id
        ORDER BY u.created_at DESC
    ");
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $users = [];
    setErrorMessage('Failed to load users.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .user-stats {
            display: flex;
            gap: 10px;
            font-size: 12px;
        }
        
        .stat-item {
            background: #f8f9fa;
            padding: 4px 8px;
            border-radius: 4px;
            color: #666;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #667eea;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .user-info-cell {
            display: flex;
            align-items: center;
        }
        
        .user-details {
            flex: 1;
        }
        
        .user-name {
            font-weight: 600;
            margin-bottom: 2px;
        }
        
        .user-meta {
            font-size: 12px;
            color: #666;
        }
        
        .quick-actions {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        .archived-user {
            opacity: 0.6;
            background: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .user-stats {
                flex-direction: column;
            }
            
            .quick-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-requests.php">Manage Requests</a></li>
                <li><a href="manage-items.php">Manage Items</a></li>
                <li><a href="manage-users.php" class="active">Manage Users</a></li>
                <li><a href="reports.php">Reports</a></li>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>Manage Users</h1>
            <p>Add, edit, and manage user accounts in the system.</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Add New User -->
        <div class="card">
            <div class="card-header">
                <h3>Add New User</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="" id="addUserForm">
                    <input type="hidden" name="action" value="add_user">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="student_number">Student Number *</label>
                                <input type="text" id="student_number" name="student_number" required 
                                       pattern="\d{6}" maxlength="6" placeholder="123456">
                                <div class="help-text">Must be exactly 6 digits</div>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="last_name">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       placeholder="Dela Cruz">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="first_name">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required 
                                       placeholder="Juan">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required 
                                       placeholder="juan.delacruz@sti.edu.ph">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="password">Password *</label>
                                <input type="password" id="password" name="password" required 
                                       minlength="6" placeholder="Minimum 6 characters">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="user_type">User Type *</label>
                                <select id="user_type" name="user_type" required>
                                    <option value="Borrower">Borrower</option>
                                    <option value="Teacher">Teacher</option>
                                    <option value="Custodian">Custodian</option>
                                    <option value="Administrator">Administrator</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="department">Department</label>
                        <input type="text" id="department" name="department" 
                               placeholder="e.g., Computer Science, Business Administration">
                    </div>
                    
                    <div class="example-text">
                        <strong>ID Number Preview:</strong> <span id="id_preview">lastname.123456</span>
                    </div>
                    
                    <div class="btn-group">
                        <button type="submit" class="btn btn-primary">Add User</button>
                        <button type="reset" class="btn btn-secondary">Clear Form</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="card">
            <div class="card-header">
                <h3>Search & Filter Users</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="filter-form">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="search">Search:</label>
                                <input type="text" id="search" name="search" 
                                       placeholder="Search by name, ID number, or email..."
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="user_type">User Type:</label>
                                <select id="user_type" name="user_type">
                                    <option value="all" <?php echo $user_type_filter == 'all' ? 'selected' : ''; ?>>All Types</option>
                                    <option value="Borrower" <?php echo $user_type_filter == 'Borrower' ? 'selected' : ''; ?>>Borrower</option>
                                    <option value="Teacher" <?php echo $user_type_filter == 'Teacher' ? 'selected' : ''; ?>>Teacher</option>
                                    <option value="Custodian" <?php echo $user_type_filter == 'Custodian' ? 'selected' : ''; ?>>Custodian</option>
                                    <option value="Administrator" <?php echo $user_type_filter == 'Administrator' ? 'selected' : ''; ?>>Administrator</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="status">Status:</label>
                                <select id="status" name="status">
                                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="archived" <?php echo $status_filter == 'archived' ? 'selected' : ''; ?>>Archived</option>
                                    <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Users Table -->
        <div class="card">
            <div class="card-header">
                <h3>Users (<?php echo count($users); ?> found)</h3>
            </div>
            <div class="card-body">
                <?php if (empty($users)): ?>
                    <p>No users found matching your criteria.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>ID Number</th>
                                    <th>Email</th>
                                    <th>Type</th>
                                    <th>Department</th>
                                    <th>Statistics</th>
                                    <th>Joined</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                <tr class="<?php echo $user['archived'] ? 'archived-user' : ''; ?>">
                                    <td>
                                        <div class="user-info-cell">
                                            <div class="user-avatar">
                                                <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                                            </div>
                                            <div class="user-details">
                                                <div class="user-name">
                                                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                                    <?php if ($user['archived']): ?>
                                                        <span class="status-badge status-secondary">Archived</span>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="user-meta">
                                                    Created: <?php echo formatDate($user['created_at']); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($user['id_number']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($user['user_type']); ?>">
                                            <?php echo $user['user_type']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['department'] ?: 'Not specified'); ?></td>
                                    <td>
                                        <div class="user-stats">
                                            <div class="stat-item">
                                                <?php echo $user['total_requests']; ?> requests
                                            </div>
                                            <?php if ($user['pending_requests'] > 0): ?>
                                            <div class="stat-item" style="background: #fff3cd; color: #856404;">
                                                <?php echo $user['pending_requests']; ?> pending
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td><?php echo formatDate($user['created_at']); ?></td>
                                    <td>
                                        <div class="quick-actions">
                                            <?php if (!$user['archived']): ?>
                                                <button class="btn btn-warning btn-sm" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)">Edit</button>
                                                <button class="btn btn-info btn-sm" onclick="resetPassword(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>')">Reset Password</button>
                                                <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="archive_user">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" 
                                                            onclick="return confirm('Are you sure you want to archive this user?')">Archive</button>
                                                </form>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="action" value="restore_user">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                    <button type="submit" class="btn btn-success btn-sm" 
                                                            onclick="return confirm('Are you sure you want to restore this user?')">Restore</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Edit User Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit User</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form method="POST" id="editForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit_user">
                    <input type="hidden" name="user_id" id="editUserId">
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editFirstName">First Name *</label>
                                <input type="text" id="editFirstName" name="first_name" required>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editLastName">Last Name *</label>
                                <input type="text" id="editLastName" name="last_name" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="editEmail">Email Address *</label>
                        <input type="email" id="editEmail" name="email" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editUserType">User Type *</label>
                                <select id="editUserType" name="user_type" required>
                                    <option value="Borrower">Borrower</option>
                                    <option value="Teacher">Teacher</option>
                                    <option value="Custodian">Custodian</option>
                                    <option value="Administrator">Administrator</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editDepartment">Department</label>
                                <input type="text" id="editDepartment" name="department">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update User</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reset Password Modal -->
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reset Password</h3>
                <span class="close" onclick="closePasswordModal()">&times;</span>
            </div>
            <form method="POST" id="passwordForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" id="passwordUserId">
                    
                    <p>Reset password for: <strong id="passwordUserName"></strong></p>
                    
                    <div class="form-group">
                        <label for="newPassword">New Password *</label>
                        <input type="password" id="newPassword" name="new_password" required 
                               minlength="6" placeholder="Minimum 6 characters">
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmPassword">Confirm Password *</label>
                        <input type="password" id="confirmPassword" required 
                               minlength="6" placeholder="Confirm new password">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closePasswordModal()">Cancel</button>
                    <button type="submit" class="btn btn-warning">Reset Password</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ID Number preview
        function updateIdPreview() {
            const lastName = document.getElementById('last_name').value.toLowerCase();
            const studentNumber = document.getElementById('student_number').value;
            const preview = lastName && studentNumber ? `${lastName}.${studentNumber}` : 'lastname.123456';
            document.getElementById('id_preview').textContent = preview;
        }

        document.getElementById('last_name').addEventListener('input', updateIdPreview);
        document.getElementById('student_number').addEventListener('input', updateIdPreview);

        // Form validation
        document.getElementById('addUserForm').addEventListener('submit', function(e) {
            const studentNumber = document.getElementById('student_number').value;
            if (!/^\d{6}$/.test(studentNumber)) {
                e.preventDefault();
                alert('Student number must be exactly 6 digits.');
                return false;
            }
        });

        // Edit user modal
        function editUser(user) {
            document.getElementById('editUserId').value = user.user_id;
            document.getElementById('editFirstName').value = user.first_name;
            document.getElementById('editLastName').value = user.last_name;
            document.getElementById('editEmail').value = user.email;
            document.getElementById('editUserType').value = user.user_type;
            document.getElementById('editDepartment').value = user.department || '';
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Reset password modal
        function resetPassword(userId, userName) {
            document.getElementById('passwordUserId').value = userId;
            document.getElementById('passwordUserName').textContent = userName;
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
            document.getElementById('passwordModal').style.display = 'block';
        }

        function closePasswordModal() {
            document.getElementById('passwordModal').style.display = 'none';
        }

        // Password confirmation validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match.');
                return false;
            }
        });

        // Close modals when clicking outside
        window.onclick = function(event) {
            const editModal = document.getElementById('editModal');
            const passwordModal = document.getElementById('passwordModal');
            
            if (event.target == editModal) {
                closeEditModal();
            }
            if (event.target == passwordModal) {
                closePasswordModal();
            }
        }

        // Auto-focus search input
        document.getElementById('search').focus();
    </script>
</body>
</html>
