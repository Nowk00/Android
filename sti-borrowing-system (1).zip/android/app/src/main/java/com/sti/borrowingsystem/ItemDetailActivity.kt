package com.sti.borrowingsystem

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityItemDetailBinding
import com.sti.borrowingsystem.models.ItemDetail
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class ItemDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityItemDetailBinding
    private lateinit var sessionManager: SessionManager
    private var itemId: Int = 0
    private var itemDetail: ItemDetail? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityItemDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        itemId = intent.getIntExtra("item_id", 0)
        
        if (itemId == 0) {
            Toast.makeText(this, "Invalid item ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        setupToolbar()
        setupSwipeRefresh()
        loadItemDetail()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Item Details"
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadItemDetail()
        }
    }

    private fun loadItemDetail() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(this, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.itemService.getItemDetail(token, itemId)

                if (response.success) {
                    itemDetail = response.data
                    updateUI(response.data)
                } else {
                    Toast.makeText(this@ItemDetailActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@ItemDetailActivity, "Failed to load item: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun updateUI(item: ItemDetail) {
        // Basic info
        binding.tvItemName.text = item.item_name
        binding.tvItemCode.text = item.item_code
        binding.tvDescription.text = item.description ?: "No description available"
        binding.tvCategory.text = item.category_name ?: "Uncategorized"
        binding.tvBrand.text = item.brand ?: "Not specified"
        binding.tvModel.text = item.model ?: "Not specified"
        binding.tvLocation.text = item.location ?: "Not specified"
        
        // Quantities
        binding.tvTotalQuantity.text = item.quantity_total.toString()
        binding.tvAvailableQuantity.text = item.quantity_available.toString()
        binding.tvBorrowedQuantity.text = item.quantity_borrowed.toString()
        
        // Condition
        binding.tvCondition.text = item.condition_status
        setConditionColor(item.condition_status)
        
        // Availability status
        val isAvailable = item.quantity_available > 0
        binding.tvAvailabilityStatus.text = if (isAvailable) "Available" else "Not Available"
        binding.tvAvailabilityStatus.setTextColor(
            getColor(if (isAvailable) R.color.status_approved else R.color.status_rejected)
        )
        
        // Specifications
        if (!item.specifications.isNullOrEmpty()) {
            binding.tvSpecifications.text = item.specifications
            binding.layoutSpecifications.visibility = View.VISIBLE
        } else {
            binding.layoutSpecifications.visibility = View.GONE
        }
        
        // Load image
        if (!item.image_path.isNullOrEmpty()) {
            Glide.with(this)
                .load(item.image_path)
                .placeholder(R.drawable.ic_item_placeholder)
                .error(R.drawable.ic_item_placeholder)
                .into(binding.ivItemImage)
        } else {
            binding.ivItemImage.setImageResource(R.drawable.ic_item_placeholder)
        }
        
        // Show/hide request button
        binding.btnRequestItem.visibility = if (isAvailable) View.VISIBLE else View.GONE
        binding.btnRequestItem.setOnClickListener {
            requestItem()
        }
    }

    private fun setConditionColor(condition: String) {
        val colorRes = when (condition.lowercase()) {
            "excellent" -> R.color.status_approved
            "good" -> R.color.status_released
            "fair" -> R.color.status_pending
            "poor", "damaged" -> R.color.status_rejected
            else -> R.color.text_secondary
        }
        
        binding.tvCondition.setTextColor(getColor(colorRes))
    }

    private fun requestItem() {
        // Navigate to create request with this item pre-selected
        val intent = android.content.Intent(this, CreateRequestActivity::class.java)
        intent.putIntegerArrayListExtra("selected_items", arrayListOf(itemId))
        startActivity(intent)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
