<?php
session_start();
require_once 'database.php';

// Authentication functions
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit();
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireUserType($allowed_types) {
    requireLogin();
    $user_type = getUserType();
    if (!in_array($user_type, $allowed_types)) {
        header('Location: dashboard.php');
        exit();
    }
}

function getUserType() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    global $pdo;
    $stmt = $pdo->prepare("SELECT user_type FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch();
    return $result ? $result['user_type'] : null;
}

function getUserInfo($user_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? AND archived = FALSE");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

// Utility functions
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

function formatDateTime($datetime) {
    return date('M d, Y g:i A', strtotime($datetime));
}

function generateItemCode() {
    return 'ITM' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function itemCodeExists($item_code) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM items WHERE item_code = ? AND archived = FALSE");
    $stmt->execute([$item_code]);
    return $stmt->fetchColumn() > 0;
}

function updateItemAvailability($item_id) {
    global $pdo;
    
    // Get total quantity
    $stmt = $pdo->prepare("SELECT quantity FROM items WHERE item_id = ?");
    $stmt->execute([$item_id]);
    $total_quantity = $stmt->fetchColumn();
    
    // Get borrowed quantity (pending and issued)
    $stmt = $pdo->prepare("
        SELECT COALESCE(SUM(ri.quantity_requested), 0) 
        FROM request_items ri 
        JOIN borrowing_requests br ON ri.request_id = br.request_id 
        WHERE ri.item_id = ? AND ri.item_status IN ('Pending', 'Issued') AND br.archived = FALSE
    ");
    $stmt->execute([$item_id]);
    $borrowed_quantity = $stmt->fetchColumn();
    
    // Update available quantity
    $available = max(0, $total_quantity - $borrowed_quantity);
    $stmt = $pdo->prepare("UPDATE items SET available_quantity = ? WHERE item_id = ?");
    $stmt->execute([$available, $item_id]);
}

// Notification functions
function createNotification($user_id, $message, $type = 'Info') {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, message, notification_type) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $message, $type]);
}

// Activity logging
function logActivity($user_id, $action_type, $description) {
    global $pdo;
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action_type, description, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $action_type, $description, $ip_address]);
}

// User management functions
function userExists($id_number, $email, $exclude_user_id = null) {
    global $pdo;
    $sql = "SELECT COUNT(*) FROM users WHERE (id_number = ? OR email = ?) AND archived = FALSE";
    $params = [$id_number, $email];
    
    if ($exclude_user_id) {
        $sql .= " AND user_id != ?";
        $params[] = $exclude_user_id;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn() > 0;
}

function generateIdNumber($last_name, $student_number) {
    return strtolower($last_name) . '.' . $student_number;
}

function validateStudentNumber($student_number) {
    return preg_match('/^\d{6}$/', $student_number);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validatePassword($password) {
    return strlen($password) >= 6;
}

// Request functions
function getRequestStatusColor($status) {
    $colors = [
        'Pending' => 'warning',
        'Approved' => 'success',
        'Rejected' => 'danger',
        'Completed' => 'info',
        'Returned' => 'secondary'
    ];
    return $colors[$status] ?? 'secondary';
}

function canEditRequest($request_id, $user_id, $user_type) {
    global $pdo;
    
    if (in_array($user_type, ['Administrator', 'Custodian'])) {
        return true;
    }
    
    $stmt = $pdo->prepare("SELECT requester_id, status FROM borrowing_requests WHERE request_id = ?");
    $stmt->execute([$request_id]);
    $request = $stmt->fetch();
    
    return $request && $request['requester_id'] == $user_id && $request['status'] == 'Pending';
}

// Room functions
function getRoomAvailability($room_id, $date, $start_time, $end_time, $exclude_request_id = null) {
    global $pdo;
    
    $sql = "
        SELECT COUNT(*) FROM room_reservations rr
        JOIN borrowing_requests br ON rr.request_id = br.request_id
        WHERE rr.room_id = ? AND rr.reserved_date = ? 
        AND br.status IN ('Pending', 'Approved', 'Completed')
        AND br.archived = FALSE
        AND (
            (rr.start_time <= ? AND rr.end_time > ?) OR
            (rr.start_time < ? AND rr.end_time >= ?) OR
            (rr.start_time >= ? AND rr.end_time <= ?)
        )
    ";
    
    $params = [$room_id, $date, $start_time, $start_time, $end_time, $end_time, $start_time, $end_time];
    
    if ($exclude_request_id) {
        $sql .= " AND rr.request_id != ?";
        $params[] = $exclude_request_id;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchColumn() == 0;
}

// Statistics functions
function getSystemStats() {
    global $pdo;
    
    $stats = [];
    
    // Total requests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowing_requests WHERE archived = FALSE");
    $stmt->execute();
    $stats['total_requests'] = $stmt->fetchColumn();
    
    // Pending requests
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowing_requests WHERE status = 'Pending' AND archived = FALSE");
    $stmt->execute();
    $stats['pending_requests'] = $stmt->fetchColumn();
    
    // Total items
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM items WHERE archived = FALSE");
    $stmt->execute();
    $stats['total_items'] = $stmt->fetchColumn();
    
    // Total users
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE archived = FALSE");
    $stmt->execute();
    $stats['total_users'] = $stmt->fetchColumn();
    
    return $stats;
}

// Error handling
function handleError($message, $redirect = null) {
    error_log($message);
    if ($redirect) {
        $_SESSION['error_message'] = 'An error occurred. Please try again.';
        header("Location: $redirect");
        exit();
    }
    return false;
}

// Success message handling
function setSuccessMessage($message) {
    $_SESSION['success_message'] = $message;
}

function setErrorMessage($message) {
    $_SESSION['error_message'] = $message;
}

function getSuccessMessage() {
    if (isset($_SESSION['success_message'])) {
        $message = $_SESSION['success_message'];
        unset($_SESSION['success_message']);
        return $message;
    }
    return null;
}

function getErrorMessage() {
    if (isset($_SESSION['error_message'])) {
        $message = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
        return $message;
    }
    return null;
}
?>
