-- STI Borrowing System Database
CREATE DATABASE IF NOT EXISTS sti_borrowing_db;
USE sti_borrowing_db;

-- Users table
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  id_number VARCHAR(20) UNIQUE NOT NULL,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  user_type ENUM('Borrower', 'Custodian', 'Administrator', 'Teacher') NOT NULL DEFAULT 'Borrower',
  department VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  archived BOOLEAN DEFAULT FALSE
);

-- Items table
CREATE TABLE items (
  item_id INT AUTO_INCREMENT PRIMARY KEY,
  item_code VARCHAR(20) UNIQUE NOT NULL,
  item_name VARCHAR(100) NOT NULL,
  description TEXT,
  quantity INT NOT NULL DEFAULT 0,
  available_quantity INT NOT NULL DEFAULT 0,
  condition_status ENUM('Good', 'Fair', 'Damaged', 'Under Repair') DEFAULT 'Good',
  location VARCHAR(255),
  maintenance_notes TEXT,
  last_maintenance TIMESTAMP NULL,
  added_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  archived BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (added_by) REFERENCES users(user_id)
);

-- Borrowing requests table
CREATE TABLE borrowing_requests (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  requester_id INT NOT NULL,
  request_type ENUM('general', 'hm_laboratory', 'room') DEFAULT 'general',
  subject VARCHAR(100) NOT NULL,
  description TEXT,
  purpose TEXT,
  scheduled_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  borrower_name VARCHAR(255),
  department VARCHAR(100),
  group_number VARCHAR(50),
  section_batch VARCHAR(100),
  day_of_week VARCHAR(20),
  room_id INT,
  class_subject VARCHAR(255),
  instructor_name VARCHAR(255),
  approved_by INT NULL,
  status ENUM('Pending', 'Approved', 'Rejected', 'Completed', 'Returned') DEFAULT 'Pending',
  rejection_reason TEXT,
  admin_notes TEXT,
  approved_at TIMESTAMP NULL,
  returned_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  return_date TIMESTAMP NULL,
  archived BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (requester_id) REFERENCES users(user_id),
  FOREIGN KEY (approved_by) REFERENCES users(user_id)
);

-- Request items table (junction table)
CREATE TABLE request_items (
  request_item_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL,
  item_id INT NOT NULL,
  quantity_requested INT NOT NULL,
  quantity_returned INT DEFAULT 0,
  item_status ENUM('Pending', 'Issued', 'Returned', 'Lost', 'Damaged') DEFAULT 'Pending',
  issued_date TIMESTAMP NULL,
  returned_date TIMESTAMP NULL,
  FOREIGN KEY (request_id) REFERENCES borrowing_requests(request_id) ON DELETE CASCADE,
  FOREIGN KEY (item_id) REFERENCES items(item_id)
);

-- Group members table for laboratory requests
CREATE TABLE request_group_members (
  member_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL,
  member_name VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (request_id) REFERENCES borrowing_requests(request_id) ON DELETE CASCADE
);

-- Rooms table for room reservations
CREATE TABLE rooms (
  room_id INT AUTO_INCREMENT PRIMARY KEY,
  room_name VARCHAR(100) NOT NULL,
  room_type ENUM('Classroom', 'Laboratory', 'Conference Room', 'Computer Lab', 'Library') DEFAULT 'Classroom',
  capacity INT DEFAULT 30,
  location VARCHAR(255),
  equipment_available TEXT,
  status ENUM('Available', 'Under Maintenance', 'Not Available') DEFAULT 'Available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  archived BOOLEAN DEFAULT FALSE
);

-- Room reservations table
CREATE TABLE room_reservations (
  reservation_id INT AUTO_INCREMENT PRIMARY KEY,
  room_id INT NOT NULL,
  request_id INT NOT NULL,
  reserved_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  status ENUM('Reserved', 'Confirmed', 'Cancelled', 'Completed') DEFAULT 'Reserved',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id) REFERENCES rooms(room_id),
  FOREIGN KEY (request_id) REFERENCES borrowing_requests(request_id)
);

-- Activity logs table
CREATE TABLE activity_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  action_type VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ip_address VARCHAR(45),
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Insert default admin user
INSERT INTO users (id_number, first_name, last_name, email, password, user_type) 
VALUES ('ADMIN001', 'System', 'Administrator', 'admin@sti.edu.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

-- Insert default custodian
INSERT INTO users (id_number, first_name, last_name, email, password, user_type) 
VALUES ('CUST001', 'John', 'Custodian', 'custodian@sti.edu.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Custodian');

-- Insert sample borrower
INSERT INTO users (id_number, first_name, last_name, email, password, user_type) 
VALUES ('STU001', 'Jane', 'Student', 'student@sti.edu.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Borrower');

-- Insert HM laboratory equipment items only
INSERT INTO items (item_code, item_name, description, quantity, available_quantity, added_by) VALUES
('HM001', 'Old Fashion Glass', 'Glass for cocktail preparation', 10, 10, 1),
('HM002', 'Shooter Glass', 'Small glass for shots', 15, 15, 1),
('HM003', 'Shot Glass', 'Standard shot glass', 15, 15, 1),
('HM004', 'Double Jigger', 'Measuring tool for liquids', 8, 8, 1),
('HM005', 'Chopping Board (Green)', 'Green cutting board for food preparation', 5, 5, 1),
('HM006', 'Shaker', 'Cocktail shaker for mixing drinks', 6, 6, 1),
('HM007', 'Long Bar Spoon', 'Long spoon for stirring cocktails', 10, 10, 1),
('HM008', 'Ice Bucket', 'Container for ice storage', 4, 4, 1),
('HM009', 'Julep Strainer', 'Strainer for cocktail preparation', 6, 6, 1),
('HM010', 'Ice Tong', 'Tongs for handling ice', 8, 8, 1),
('HM011', 'Paring Knife', 'Small knife for garnish preparation', 10, 10, 1),
('HM012', 'Ice Scoop', 'Scoop for ice handling', 6, 6, 1),
('HM013', 'Muddler', 'Tool for muddling ingredients', 8, 8, 1);

-- Insert sample rooms
INSERT INTO rooms (room_name, room_type, capacity, location, equipment_available) VALUES
('Room 101', 'Classroom', 40, 'First Floor', 'Projector, Whiteboard, Air Conditioning'),
('Room 102', 'Classroom', 35, 'First Floor', 'Projector, Whiteboard, Air Conditioning'),
('Computer Lab 1', 'Computer Lab', 30, 'Second Floor', '30 Computers, Projector, Air Conditioning'),
('Computer Lab 2', 'Computer Lab', 25, 'Second Floor', '25 Computers, Projector, Air Conditioning'),
('HM Laboratory', 'Laboratory', 20, 'Third Floor', 'Kitchen Equipment, Cooking Utensils, Refrigerator'),
('Conference Room A', 'Conference Room', 15, 'Fourth Floor', 'Conference Table, Projector, Video Conferencing'),
('Library Study Room 1', 'Library', 8, 'Library Wing', 'Study Tables, Whiteboard, Quiet Environment'),
('Library Study Room 2', 'Library', 12, 'Library Wing', 'Study Tables, Whiteboard, Quiet Environment');
