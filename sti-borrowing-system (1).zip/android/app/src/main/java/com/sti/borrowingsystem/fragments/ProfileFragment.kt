package com.sti.borrowingsystem.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.sti.borrowingsystem.ChangePasswordActivity
import com.sti.borrowingsystem.EditProfileActivity
import com.sti.borrowingsystem.LoginActivity
import com.sti.borrowingsystem.NotificationSettingsActivity
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.FragmentProfileBinding
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {
    
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var sessionManager: SessionManager
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        sessionManager = SessionManager(requireContext())
        setupUI()
        setupClickListeners()
        loadUserProfile()
    }
    
    private fun setupUI() {
        val user = sessionManager.getUser()
        user?.let {
            binding.tvUserName.text = "${it.first_name} ${it.last_name}"
            binding.tvUserIdNumber.text = it.id_number
            binding.tvUserEmail.text = it.email
            binding.tvUserType.text = it.user_type
            binding.tvUserDepartment.text = it.department ?: "Not specified"
            binding.tvUserCourse.text = it.course ?: "Not specified"
            binding.tvUserYearLevel.text = "${it.year_level ?: 0} Year"
        }
    }
    
    private fun setupClickListeners() {
        binding.cardEditProfile.setOnClickListener {
            startActivityForResult(Intent(context, EditProfileActivity::class.java), REQUEST_EDIT_PROFILE)
        }
        
        binding.cardChangePassword.setOnClickListener {
            startActivity(Intent(context, ChangePasswordActivity::class.java))
        }
        
        binding.cardNotificationSettings.setOnClickListener {
            startActivity(Intent(context, NotificationSettingsActivity::class.java))
        }
        
        binding.cardAbout.setOnClickListener {
            showAboutDialog()
        }
        
        binding.cardHelp.setOnClickListener {
            showHelpDialog()
        }
        
        binding.cardLogout.setOnClickListener {
            showLogoutDialog()
        }
        
        binding.swipeRefresh.setOnRefreshListener {
            loadUserProfile()
        }
    }
    
    fun refreshData() {
        loadUserProfile()
    }
    
    private fun loadUserProfile() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(context, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val response = ApiClient.authService.getProfile(token)
                
                if (response.success) {
                    // Update session with latest user data
                    sessionManager.updateUser(response.data)
                    setupUI()
                    
                    // Update statistics
                    binding.tvTotalRequests.text = response.data.total_requests?.toString() ?: "0"
                    binding.tvPendingRequests.text = response.data.pending_requests?.toString() ?: "0"
                    binding.tvCompletedRequests.text = response.data.completed_requests?.toString() ?: "0"
                } else {
                    Toast.makeText(context, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load profile: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun showAboutDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("About STI Borrowing System")
            .setMessage("STI College Balagtas Borrowing System\n\nVersion: 1.0.0\nDeveloped for: STI College Balagtas\n\nThis mobile application allows students to easily submit and track borrowing requests for laboratory equipment, sports materials, and other institutional resources.")
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun showHelpDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Help & Support")
            .setMessage("Need help with the borrowing system?\n\nContact Information:\n• Email: support@stibalagtas.edu.ph\n• Phone: (044) 123-4567\n• Office: Student Services Office\n\nOffice Hours:\nMonday - Friday: 8:00 AM - 5:00 PM\nSaturday: 8:00 AM - 12:00 PM")
            .setPositiveButton("OK", null)
            .setNegativeButton("Call Support") { _, _ ->
                // Open dialer with support number
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = android.net.Uri.parse("tel:+63441234567")
                startActivity(intent)
            }
            .show()
    }
    
    private fun showLogoutDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                logout()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun logout() {
        sessionManager.clearSession()
        val intent = Intent(context, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        activity?.finish()
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_EDIT_PROFILE && resultCode == android.app.Activity.RESULT_OK) {
            loadUserProfile()
        }
    }
    
    override fun onResume() {
        super.onResume()
        setupUI() // Refresh UI in case user data changed
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        private const val REQUEST_EDIT_PROFILE = 1001
    }
}
