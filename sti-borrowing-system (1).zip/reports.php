<?php
require_once 'config/functions.php';
requireUserType(['Administrator']);

$user_info = getUserInfo($_SESSION['user_id']);

// Get date range from query parameters
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-1 month'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$report_type = $_GET['report_type'] ?? 'overview';

try {
    // Overview Statistics
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_requests,
            COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_requests,
            COUNT(CASE WHEN status = 'Approved' THEN 1 END) as approved_requests,
            COUNT(CASE WHEN status = 'Rejected' THEN 1 END) as rejected_requests,
            COUNT(CASE WHEN status = 'Completed' THEN 1 END) as completed_requests,
            COUNT(CASE WHEN status = 'Returned' THEN 1 END) as returned_requests
        FROM borrowing_requests 
        WHERE created_at BETWEEN ? AND ? AND archived = FALSE
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $overview_stats = $stmt->fetch();
    
    // Monthly trends for the past 12 months
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(created_at, '%Y-%m') as month,
            COUNT(*) as request_count,
            COUNT(CASE WHEN status = 'Approved' THEN 1 END) as approved_count,
            COUNT(CASE WHEN status = 'Rejected' THEN 1 END) as rejected_count
        FROM borrowing_requests 
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) 
        AND archived = FALSE
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    $monthly_trends = $stmt->fetchAll();
    
    // Most active users
    $stmt = $pdo->prepare("
        SELECT 
            u.first_name, u.last_name, u.id_number, u.user_type,
            COUNT(br.request_id) as total_requests,
            COUNT(CASE WHEN br.status = 'Approved' THEN 1 END) as approved_requests
        FROM users u
        LEFT JOIN borrowing_requests br ON u.user_id = br.requester_id 
            AND br.created_at BETWEEN ? AND ? AND br.archived = FALSE
        WHERE u.archived = FALSE
        GROUP BY u.user_id
        HAVING total_requests > 0
        ORDER BY total_requests DESC
        LIMIT 10
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $active_users = $stmt->fetchAll();
    
    // Most borrowed items
    $stmt = $pdo->prepare("
        SELECT 
            i.item_name, i.item_code,
            SUM(ri.quantity_requested) as total_borrowed,
            COUNT(ri.request_item_id) as borrow_count
        FROM items i
        JOIN request_items ri ON i.item_id = ri.item_id
        JOIN borrowing_requests br ON ri.request_id = br.request_id
        WHERE br.created_at BETWEEN ? AND ? AND br.archived = FALSE
        GROUP BY i.item_id
        ORDER BY total_borrowed DESC
        LIMIT 10
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $popular_items = $stmt->fetchAll();
    
    // Item utilization report
    $stmt = $pdo->prepare("
        SELECT 
            i.item_name, i.item_code, i.quantity, i.available_quantity,
            COALESCE(SUM(ri.quantity_requested), 0) as times_borrowed,
            ROUND((COALESCE(SUM(ri.quantity_requested), 0) / i.quantity) * 100, 2) as utilization_rate
        FROM items i
        LEFT JOIN request_items ri ON i.item_id = ri.item_id
        LEFT JOIN borrowing_requests br ON ri.request_id = br.request_id 
            AND br.created_at BETWEEN ? AND ? AND br.archived = FALSE
        WHERE i.archived = FALSE
        GROUP BY i.item_id
        ORDER BY utilization_rate DESC
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $item_utilization = $stmt->fetchAll();
    
    // Department/User type analysis
    $stmt = $pdo->prepare("
        SELECT 
            u.user_type,
            COUNT(DISTINCT u.user_id) as user_count,
            COUNT(br.request_id) as total_requests,
            AVG(CASE WHEN br.status = 'Approved' THEN 1.0 ELSE 0.0 END) * 100 as approval_rate
        FROM users u
        LEFT JOIN borrowing_requests br ON u.user_id = br.requester_id 
            AND br.created_at BETWEEN ? AND ? AND br.archived = FALSE
        WHERE u.archived = FALSE
        GROUP BY u.user_type
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $user_type_analysis = $stmt->fetchAll();
    
    // Recent activity log
    $stmt = $pdo->prepare("
        SELECT al.*, u.first_name, u.last_name, u.user_type
        FROM activity_logs al
        JOIN users u ON al.user_id = u.user_id
        WHERE al.timestamp BETWEEN ? AND ?
        ORDER BY al.timestamp DESC
        LIMIT 50
    ");
    $stmt->execute([$date_from . ' 00:00:00', $date_to . ' 23:59:59']);
    $recent_activities = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $overview_stats = $monthly_trends = $active_users = $popular_items = [];
    $item_utilization = $user_type_analysis = $recent_activities = [];
    $error_message = 'Failed to generate reports.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .report-filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        .report-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
        }
        
        .report-tab {
            padding: 10px 20px;
            background: none;
            border: none;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            font-weight: 500;
        }
        
        .report-tab.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .report-section {
            display: none;
        }
        
        .report-section.active {
            display: block;
        }
        
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .summary-number {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .summary-label {
            color: #666;
            font-size: 14px;
        }
        
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .export-buttons {
            margin-bottom: 20px;
        }
        
        @media print {
            .header, .nav, .export-buttons, .report-filters {
                display: none;
            }
            
            .main-content {
                margin: 0;
                padding: 0;
            }
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-requests.php">Manage Requests</a></li>
                <li><a href="manage-items.php">Manage Items</a></li>
                <li><a href="manage-users.php">Manage Users</a></li>
                <li><a href="reports.php" class="active">Reports</a></li>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>System Reports & Analytics</h1>
            <p>Comprehensive reports and insights for the borrowing system.</p>
        </div>

        <!-- Report Filters -->
        <div class="report-filters">
            <form method="GET" action="" class="filter-form">
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="date_from">From Date:</label>
                            <input type="date" id="date_from" name="date_from" value="<?php echo $date_from; ?>">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="date_to">To Date:</label>
                            <input type="date" id="date_to" name="date_to" value="<?php echo $date_to; ?>">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary">Generate Report</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- Export Buttons -->
        <div class="export-buttons">
            <button onclick="window.print()" class="btn btn-secondary">Print Report</button>
            <button onclick="exportToCSV()" class="btn btn-info">Export to CSV</button>
        </div>

        <!-- Report Tabs -->
        <div class="report-tabs">
            <button class="report-tab active" onclick="showReport('overview')">Overview</button>
            <button class="report-tab" onclick="showReport('users')">User Analysis</button>
            <button class="report-tab" onclick="showReport('items')">Item Analysis</button>
            <button class="report-tab" onclick="showReport('activity')">Activity Log</button>
        </div>

        <!-- Overview Report -->
        <div id="overview" class="report-section active">
            <h2>📊 System Overview (<?php echo formatDate($date_from); ?> - <?php echo formatDate($date_to); ?>)</h2>
            
            <div class="stats-summary">
                <div class="summary-card">
                    <div class="summary-number"><?php echo $overview_stats['total_requests'] ?? 0; ?></div>
                    <div class="summary-label">Total Requests</div>
                </div>
                <div class="summary-card">
                    <div class="summary-number"><?php echo $overview_stats['approved_requests'] ?? 0; ?></div>
                    <div class="summary-label">Approved</div>
                </div>
                <div class="summary-card">
                    <div class="summary-number"><?php echo $overview_stats['rejected_requests'] ?? 0; ?></div>
                    <div class="summary-label">Rejected</div>
                </div>
                <div class="summary-card">
                    <div class="summary-number"><?php echo $overview_stats['pending_requests'] ?? 0; ?></div>
                    <div class="summary-label">Pending</div>
                </div>
                <div class="summary-card">
                    <div class="summary-number">
                        <?php 
                        $total = $overview_stats['total_requests'] ?? 0;
                        $approved = $overview_stats['approved_requests'] ?? 0;
                        echo $total > 0 ? round(($approved / $total) * 100, 1) . '%' : '0%';
                        ?>
                    </div>
                    <div class="summary-label">Approval Rate</div>
                </div>
            </div>

            <div class="chart-grid">
                <div class="chart-container">
                    <div class="chart-header">
                        <h3>📈 Monthly Trends (Last 12 Months)</h3>
                    </div>
                    <div class="chart-canvas">
                        <canvas id="monthlyTrendsChart"></canvas>
                    </div>
                </div>

                <div class="chart-container">
                    <div class="chart-header">
                        <h3>👥 User Type Distribution</h3>
                    </div>
                    <div class="chart-canvas">
                        <canvas id="userTypeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Analysis Report -->
        <div id="users" class="report-section">
            <h2>👥 User Analysis</h2>
            
            <div class="card">
                <div class="card-header">
                    <h3>Most Active Users</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($active_users)): ?>
                        <p>No user activity found in the selected date range.</p>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>ID Number</th>
                                        <th>Type</th>
                                        <th>Total Requests</th>
                                        <th>Approved</th>
                                        <th>Success Rate</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($active_users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['id_number']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo strtolower($user['user_type']); ?>">
                                                <?php echo $user['user_type']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $user['total_requests']; ?></td>
                                        <td><?php echo $user['approved_requests']; ?></td>
                                        <td>
                                            <?php 
                                            $rate = $user['total_requests'] > 0 ? 
                                                round(($user['approved_requests'] / $user['total_requests']) * 100, 1) : 0;
                                            echo $rate . '%';
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>User Type Analysis</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User Type</th>
                                    <th>Total Users</th>
                                    <th>Total Requests</th>
                                    <th>Approval Rate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($user_type_analysis as $analysis): ?>
                                <tr>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($analysis['user_type']); ?>">
                                            <?php echo $analysis['user_type']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $analysis['user_count']; ?></td>
                                    <td><?php echo $analysis['total_requests']; ?></td>
                                    <td><?php echo round($analysis['approval_rate'], 1); ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Item Analysis Report -->
        <div id="items" class="report-section">
            <h2>📦 Item Analysis</h2>
            
            <div class="card">
                <div class="card-header">
                    <h3>Most Popular Items</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($popular_items)): ?>
                        <p>No item borrowing activity found in the selected date range.</p>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Item Code</th>
                                        <th>Item Name</th>
                                        <th>Times Borrowed</th>
                                        <th>Total Quantity</th>
                                        <th>Borrow Frequency</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($popular_items as $item): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($item['item_code']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                        <td><?php echo $item['total_borrowed']; ?></td>
                                        <td><?php echo $item['borrow_count']; ?></td>
                                        <td>
                                            <div style="background: #f0f0f0; border-radius: 10px; height: 20px; position: relative;">
                                                <div style="background: #667eea; height: 100%; border-radius: 10px; width: <?php echo min(100, ($item['borrow_count'] / max(1, $popular_items[0]['borrow_count'])) * 100); ?>%;"></div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>Item Utilization Report</h3>
                </div>
                <div class="card-body">
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Name</th>
                                    <th>Total Quantity</th>
                                    <th>Available</th>
                                    <th>Times Borrowed</th>
                                    <th>Utilization Rate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($item_utilization as $item): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['item_code']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td><?php echo $item['available_quantity']; ?></td>
                                    <td><?php echo $item['times_borrowed']; ?></td>
                                    <td>
                                        <span class="<?php echo $item['utilization_rate'] > 50 ? 'text-success' : ($item['utilization_rate'] > 20 ? 'text-warning' : 'text-danger'); ?>">
                                            <?php echo $item['utilization_rate']; ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity Log Report -->
        <div id="activity" class="report-section">
            <h2>📋 Activity Log</h2>
            
            <div class="card">
                <div class="card-header">
                    <h3>Recent System Activities</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($recent_activities)): ?>
                        <p>No activities found in the selected date range.</p>
                    <?php else: ?>
                        <div class="table-container">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Timestamp</th>
                                        <th>User</th>
                                        <th>Action Type</th>
                                        <th>Description</th>
                                        <th>IP Address</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_activities as $activity): ?>
                                    <tr>
                                        <td><?php echo formatDateTime($activity['timestamp']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?>
                                            <br><small class="text-muted"><?php echo $activity['user_type']; ?></small>
                                        </td>
                                        <td>
                                            <span class="status-badge status-info">
                                                <?php echo htmlspecialchars($activity['action_type']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($activity['description']); ?></td>
                                        <td><small><?php echo htmlspecialchars($activity['ip_address']); ?></small></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Monthly Trends Chart
        const monthlyData = <?php echo json_encode($monthly_trends); ?>;
        const months = monthlyData.map(item => {
            const date = new Date(item.month + '-01');
            return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
        });
        const requestCounts = monthlyData.map(item => item.request_count);
        const approvedCounts = monthlyData.map(item => item.approved_count);

        const monthlyCtx = document.getElementById('monthlyTrendsChart').getContext('2d');
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Total Requests',
                    data: requestCounts,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Approved Requests',
                    data: approvedCounts,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // User Type Chart
        const userTypeData = <?php echo json_encode($user_type_analysis); ?>;
        const userTypeLabels = userTypeData.map(item => item.user_type);
        const userTypeCounts = userTypeData.map(item => item.user_count);

        const userTypeCtx = document.getElementById('userTypeChart').getContext('2d');
        new Chart(userTypeCtx, {
            type: 'doughnut',
            data: {
                labels: userTypeLabels,
                datasets: [{
                    data: userTypeCounts,
                    backgroundColor: ['#667eea', '#28a745', '#ffc107'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Report tab switching
        function showReport(reportType) {
            // Hide all sections
            document.querySelectorAll('.report-section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.report-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected section
            document.getElementById(reportType).classList.add('active');
            
            // Add active class to clicked tab
            event.target.classList.add('active');
        }

        // Export to CSV function
        function exportToCSV() {
            const activeSection = document.querySelector('.report-section.active');
            const tables = activeSection.querySelectorAll('table');
            
            if (tables.length === 0) {
                alert('No data to export');
                return;
            }
            
            let csvContent = '';
            
            tables.forEach((table, index) => {
                if (index > 0) csvContent += '\n\n';
                
                // Add table header
                const headerCells = table.querySelectorAll('thead th');
                const headers = Array.from(headerCells).map(cell => cell.textContent.trim());
                csvContent += headers.join(',') + '\n';
                
                // Add table rows
                const rows = table.querySelectorAll('tbody tr');
                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    const rowData = Array.from(cells).map(cell => {
                        return '"' + cell.textContent.trim().replace(/"/g, '""') + '"';
                    });
                    csvContent += rowData.join(',') + '\n';
                });
            });
            
            // Download CSV
            const blob = new Blob([csvContent], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'sti_borrowing_report_' + new Date().toISOString().split('T')[0] + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }
    </script>
</body>
</html>
