<?php
require_once 'config.php';

$user = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        getItems();
        break;
    
    default:
        sendResponse(false, 'Method not allowed', null, 405);
}

function getItems() {
    global $pdo;
    
    try {
        $search = $_GET['search'] ?? '';
        $condition = $_GET['condition'] ?? 'all';
        $available_only = isset($_GET['available_only']) && $_GET['available_only'] == 'true';
        
        $where_conditions = ["i.archived = FALSE"];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(i.item_name LIKE ? OR i.item_code LIKE ? OR i.description LIKE ?)";
            $search_param = "%$search%";
            $params = array_merge($params, [$search_param, $search_param, $search_param]);
        }
        
        if ($condition !== 'all') {
            $where_conditions[] = "i.condition_status = ?";
            $params[] = $condition;
        }
        
        if ($available_only) {
            $where_conditions[] = "i.available_quantity > 0";
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $stmt = $pdo->prepare("
            SELECT i.item_id, i.item_code, i.item_name, i.description, 
                   i.quantity, i.available_quantity, i.condition_status,
                   COALESCE(SUM(CASE WHEN ri.item_status IN ('Pending', 'Issued') THEN ri.quantity_requested ELSE 0 END), 0) as borrowed_qty
            FROM items i
            LEFT JOIN request_items ri ON i.item_id = ri.item_id
            WHERE $where_clause
            GROUP BY i.item_id
            ORDER BY i.item_name ASC
        ");
        $stmt->execute($params);
        $items = $stmt->fetchAll();
        
        sendResponse(true, 'Items retrieved successfully', $items);
        
    } catch (PDOException $e) {
        sendResponse(false, 'Failed to retrieve items', null, 500);
    }
}
?>
