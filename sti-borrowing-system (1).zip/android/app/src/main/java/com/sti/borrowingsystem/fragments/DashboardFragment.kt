package com.sti.borrowingsystem.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.sti.borrowingsystem.CreateRequestActivity
import com.sti.borrowingsystem.MainActivity
import com.sti.borrowingsystem.R
import com.sti.borrowingsystem.RequestDetailActivity
import com.sti.borrowingsystem.adapters.RecentRequestsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.FragmentDashboardBinding
import com.sti.borrowingsystem.models.DashboardData
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class DashboardFragment : Fragment() {
    
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var sessionManager: SessionManager
    private lateinit var recentRequestsAdapter: RecentRequestsAdapter
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        sessionManager = SessionManager(requireContext())
        setupUI()
        setupRecyclerView()
        setupSwipeRefresh()
        loadDashboardData()
    }
    
    private fun setupUI() {
        val user = sessionManager.getUser()
        binding.tvWelcome.text = "Welcome back, ${user?.first_name}!"
        
        // Quick action buttons
        binding.btnCreateRequest.setOnClickListener {
            startActivityForResult(Intent(context, CreateRequestActivity::class.java), REQUEST_CREATE)
        }
        
        binding.btnViewAllRequests.setOnClickListener {
            // Switch to requests tab
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.binding.bottomNavigation.selectedItemId = R.id.navigation_my_requests
            }
        }
        
        binding.btnBrowseItems.setOnClickListener {
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.binding.bottomNavigation.selectedItemId = R.id.navigation_browse_items
            }
        }
        
        binding.btnProfile.setOnClickListener {
            (activity as? MainActivity)?.let { mainActivity ->
                mainActivity.binding.bottomNavigation.selectedItemId = R.id.navigation_profile
            }
        }
    }
    
    private fun setupRecyclerView() {
        recentRequestsAdapter = RecentRequestsAdapter { request ->
            val intent = Intent(context, RequestDetailActivity::class.java)
            intent.putExtra("request_id", request.request_id)
            startActivity(intent)
        }
        
        binding.rvRecentRequests.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = recentRequestsAdapter
        }
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadDashboardData()
        }
    }
    
    fun refreshData() {
        loadDashboardData()
    }
    
    private fun loadDashboardData() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(context, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val response = ApiClient.dashboardService.getDashboardData(token)
                
                if (response.success) {
                    updateUI(response.data)
                } else {
                    Toast.makeText(context, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load dashboard: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun updateUI(data: DashboardData) {
        // Update statistics cards
        data.user_stats?.let { stats ->
            binding.tvTotalRequests.text = stats.total_requests.toString()
            binding.tvPendingRequests.text = stats.pending_requests.toString()
            binding.tvApprovedRequests.text = stats.approved_requests.toString()
            binding.tvCompletedRequests.text = stats.completed_requests.toString()
        }
        
        // Update recent requests
        recentRequestsAdapter.updateRequests(data.recent_requests)
        
        // Show/hide empty state
        if (data.recent_requests.isEmpty()) {
            binding.tvEmptyRequests.visibility = View.VISIBLE
            binding.rvRecentRequests.visibility = View.GONE
        } else {
            binding.tvEmptyRequests.visibility = View.GONE
            binding.rvRecentRequests.visibility = View.VISIBLE
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CREATE && resultCode == android.app.Activity.RESULT_OK) {
            // Refresh dashboard when returning from create request
            loadDashboardData()
        }
    }
    
    override fun onResume() {
        super.onResume()
        loadDashboardData()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        private const val REQUEST_CREATE = 1001
    }
}
