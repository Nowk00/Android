<?php
session_start();

// Log activity before destroying session
if (isset($_SESSION["user_id"])) {
    require_once "config/functions.php";
    logActivity($_SESSION["user_id"], "Logout", "User logged out");
}

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to login page
header("location: index.php");
exit;
?>
