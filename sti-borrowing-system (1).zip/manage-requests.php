<?php
require_once 'config/functions.php';
requireUserType(['Custodian', 'Administrator']);

$user_info = getUserInfo($_SESSION['user_id']);
$user_type = getUserType();

$success_message = '';
$error_message = '';

// Handle request actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $request_id = $_POST['request_id'] ?? '';
    
    if ($action && $request_id) {
        try {
            switch ($action) {
                case 'approve':
                    $stmt = $pdo->prepare("
                        UPDATE borrowing_requests 
                        SET status = 'Approved', approved_by = ? 
                        WHERE request_id = ? AND status = 'Pending'
                    ");
                    $stmt->execute([$_SESSION['user_id'], $request_id]);
                    
                    // Update request items status
                    $stmt = $pdo->prepare("
                        UPDATE request_items 
                        SET item_status = 'Issued', issued_date = NOW() 
                        WHERE request_id = ?
                    ");
                    $stmt->execute([$request_id]);
                    
                    // Update item availability
                    $stmt = $pdo->prepare("SELECT item_id FROM request_items WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    $items = $stmt->fetchAll();
                    foreach ($items as $item) {
                        updateItemAvailability($item['item_id']);
                    }
                    
                    // Get requester info for notification
                    $stmt = $pdo->prepare("SELECT requester_id FROM borrowing_requests WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    $requester_id = $stmt->fetchColumn();
                    
                    createNotification($requester_id, "Your borrowing request #$request_id has been approved!", 'Success');
                    logActivity($_SESSION['user_id'], 'Approve Request', "Approved borrowing request #$request_id");
                    
                    $success_message = "Request #$request_id has been approved successfully!";
                    break;
                    
                case 'reject':
                    $reason = sanitizeInput($_POST['reason'] ?? 'No reason provided');
                    $stmt = $pdo->prepare("
                        UPDATE borrowing_requests 
                        SET status = 'Rejected', approved_by = ? 
                        WHERE request_id = ? AND status = 'Pending'
                    ");
                    $stmt->execute([$_SESSION['user_id'], $request_id]);
                    
                    // Update request items status
                    $stmt = $pdo->prepare("
                        UPDATE request_items 
                        SET item_status = 'Rejected' 
                        WHERE request_id = ?
                    ");
                    $stmt->execute([$request_id]);
                    
                    // Update item availability
                    $stmt = $pdo->prepare("SELECT item_id FROM request_items WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    $items = $stmt->fetchAll();
                    foreach ($items as $item) {
                        updateItemAvailability($item['item_id']);
                    }
                    
                    // Get requester info for notification
                    $stmt = $pdo->prepare("SELECT requester_id FROM borrowing_requests WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    $requester_id = $stmt->fetchColumn();
                    
                    createNotification($requester_id, "Your borrowing request #$request_id has been rejected. Reason: $reason", 'Warning');
                    logActivity($_SESSION['user_id'], 'Reject Request', "Rejected borrowing request #$request_id - Reason: $reason");
                    
                    $success_message = "Request #$request_id has been rejected.";
                    break;
                    
                case 'complete':
                    $stmt = $pdo->prepare("
                        UPDATE borrowing_requests 
                        SET status = 'Completed' 
                        WHERE request_id = ? AND status = 'Approved'
                    ");
                    $stmt->execute([$request_id]);
                    
                    logActivity($_SESSION['user_id'], 'Complete Request', "Marked borrowing request #$request_id as completed");
                    $success_message = "Request #$request_id has been marked as completed.";
                    break;
                    
                case 'return':
                    $stmt = $pdo->prepare("
                        UPDATE borrowing_requests 
                        SET status = 'Returned', return_date = NOW() 
                        WHERE request_id = ? AND status IN ('Approved', 'Completed')
                    ");
                    $stmt->execute([$request_id]);
                    
                    // Update request items
                    $stmt = $pdo->prepare("
                        UPDATE request_items 
                        SET item_status = 'Returned', returned_date = NOW(), quantity_returned = quantity_requested 
                        WHERE request_id = ?
                    ");
                    $stmt->execute([$request_id]);
                    
                    // Update item availability
                    $stmt = $pdo->prepare("SELECT item_id FROM request_items WHERE request_id = ?");
                    $stmt->execute([$request_id]);
                    $items = $stmt->fetchAll();
                    foreach ($items as $item) {
                        updateItemAvailability($item['item_id']);
                    }
                    
                    logActivity($_SESSION['user_id'], 'Return Items', "Processed return for borrowing request #$request_id");
                    $success_message = "Items for request #$request_id have been returned successfully.";
                    break;
            }
        } catch(PDOException $e) {
            $error_message = 'Failed to process request. Please try again.';
            error_log("Manage request error: " . $e->getMessage());
        }
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$date_filter = $_GET['date'] ?? 'all';

// Build query based on filters
$where_conditions = ["br.archived = FALSE"];
$params = [];

if ($status_filter !== 'all') {
    $where_conditions[] = "br.status = ?";
    $params[] = $status_filter;
}

if ($date_filter !== 'all') {
    switch ($date_filter) {
        case 'today':
            $where_conditions[] = "DATE(br.created_at) = CURDATE()";
            break;
        case 'week':
            $where_conditions[] = "br.created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)";
            break;
        case 'month':
            $where_conditions[] = "br.created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            break;
    }
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $stmt = $pdo->prepare("
        SELECT br.*, 
               u.first_name, u.last_name, u.id_number,
               approver.first_name as approver_first_name, approver.last_name as approver_last_name,
               GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list,
               COUNT(ri.request_item_id) as item_count
        FROM borrowing_requests br
        JOIN users u ON br.requester_id = u.user_id
        LEFT JOIN users approver ON br.approved_by = approver.user_id
        LEFT JOIN request_items ri ON br.request_id = ri.request_id
        LEFT JOIN items i ON ri.item_id = i.item_id
        WHERE $where_clause
        GROUP BY br.request_id
        ORDER BY br.created_at DESC
    ");
    $stmt->execute($params);
    $requests = $stmt->fetchAll();
} catch(PDOException $e) {
    $requests = [];
    $error_message = 'Failed to load requests.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Requests - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-requests.php" class="active">Manage Requests</a></li>
                <li><a href="manage-items.php">Manage Items</a></li>
                <?php if ($user_type == 'Administrator'): ?>
                    <li><a href="manage-users.php">Manage Users</a></li>
                    <li><a href="reports.php">Reports</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>Manage Borrowing Requests</h1>
            <p>Review, approve, and manage all borrowing requests in the system.</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="card">
            <div class="card-header">
                <h3>Filter Requests</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="filter-form">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="status">Status:</label>
                                <select id="status" name="status">
                                    <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Status</option>
                                    <option value="Pending" <?php echo $status_filter == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Approved" <?php echo $status_filter == 'Approved' ? 'selected' : ''; ?>>Approved</option>
                                    <option value="Rejected" <?php echo $status_filter == 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                                    <option value="Completed" <?php echo $status_filter == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Returned" <?php echo $status_filter == 'Returned' ? 'selected' : ''; ?>>Returned</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="date">Date Range:</label>
                                <select id="date" name="date">
                                    <option value="all" <?php echo $date_filter == 'all' ? 'selected' : ''; ?>>All Time</option>
                                    <option value="today" <?php echo $date_filter == 'today' ? 'selected' : ''; ?>>Today</option>
                                    <option value="week" <?php echo $date_filter == 'week' ? 'selected' : ''; ?>>This Week</option>
                                    <option value="month" <?php echo $date_filter == 'month' ? 'selected' : ''; ?>>This Month</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary">Apply Filters</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Requests Table -->
        <div class="card">
            <div class="card-header">
                <h3>Borrowing Requests (<?php echo count($requests); ?> found)</h3>
            </div>
            <div class="card-body">
                <?php if (empty($requests)): ?>
                    <p>No requests found matching your criteria.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Requester</th>
                                    <th>Subject</th>
                                    <th>Items</th>
                                    <th>Scheduled Date</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requests as $request): ?>
                                <tr>
                                    <td>#<?php echo str_pad($request['request_id'], 4, '0', STR_PAD_LEFT); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></strong>
                                        <br><small><?php echo htmlspecialchars($request['id_number']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($request['subject']); ?></td>
                                    <td>
                                        <small><?php echo htmlspecialchars($request['items_list'] ?: 'No items'); ?></small>
                                        <br><span class="text-muted"><?php echo $request['item_count']; ?> item(s)</span>
                                    </td>
                                    <td><?php echo formatDate($request['scheduled_date']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                                            <?php echo $request['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($request['created_at']); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view-request.php?id=<?php echo $request['request_id']; ?>" class="btn btn-info btn-sm">View</a>
                                            
                                            <?php if ($request['status'] == 'Pending'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                                    <input type="hidden" name="action" value="approve">
                                                    <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Approve this request?')">Approve</button>
                                                </form>
                                                <button class="btn btn-danger btn-sm" onclick="showRejectModal(<?php echo $request['request_id']; ?>)">Reject</button>
                                            <?php elseif ($request['status'] == 'Approved'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                                    <input type="hidden" name="action" value="complete">
                                                    <button type="submit" class="btn btn-warning btn-sm" onclick="return confirm('Mark as completed?')">Complete</button>
                                                </form>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                                    <input type="hidden" name="action" value="return">
                                                    <button type="submit" class="btn btn-secondary btn-sm" onclick="return confirm('Process return?')">Return</button>
                                                </form>
                                            <?php elseif ($request['status'] == 'Completed'): ?>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                                    <input type="hidden" name="action" value="return">
                                                    <button type="submit" class="btn btn-secondary btn-sm" onclick="return confirm('Process return?')">Return</button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reject Request</h3>
                <span class="close" onclick="closeRejectModal()">&times;</span>
            </div>
            <form method="POST" id="rejectForm">
                <div class="modal-body">
                    <input type="hidden" name="request_id" id="rejectRequestId">
                    <input type="hidden" name="action" value="reject">
                    <div class="form-group">
                        <label for="reason">Reason for rejection:</label>
                        <textarea id="reason" name="reason" rows="4" required placeholder="Please provide a reason for rejecting this request..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Request</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showRejectModal(requestId) {
            document.getElementById('rejectRequestId').value = requestId;
            document.getElementById('rejectModal').style.display = 'block';
        }

        function closeRejectModal() {
            document.getElementById('rejectModal').style.display = 'none';
            document.getElementById('reason').value = '';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('rejectModal');
            if (event.target == modal) {
                closeRejectModal();
            }
        }
    </script>
</body>
</html>
