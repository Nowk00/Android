package com.sti.borrowingsystem

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.sti.borrowingsystem.adapters.RequestItemsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityRequestDetailBinding
import com.sti.borrowingsystem.models.BorrowingRequestDetail
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class RequestDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRequestDetailBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var requestItemsAdapter: RequestItemsAdapter
    private var requestId: Int = 0
    private var requestDetail: BorrowingRequestDetail? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRequestDetailBinding
        super.onCreate(savedInstanceState)
        binding = ActivityRequestDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        requestId = intent.getIntExtra("request_id", 0)
        
        if (requestId == 0) {
            Toast.makeText(this, "Invalid request ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        setupToolbar()
        setupRecyclerView()
        setupSwipeRefresh()
        loadRequestDetail()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Request Details"
    }

    private fun setupRecyclerView() {
        requestItemsAdapter = RequestItemsAdapter()
        
        binding.rvRequestItems.apply {
            layoutManager = LinearLayoutManager(this@RequestDetailActivity)
            adapter = requestItemsAdapter
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadRequestDetail()
        }
    }

    private fun loadRequestDetail() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(this, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.requestService.getRequestDetail(token, requestId)

                if (response.success) {
                    requestDetail = response.data
                    updateUI(response.data)
                } else {
                    Toast.makeText(this@RequestDetailActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RequestDetailActivity, "Failed to load request: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun updateUI(request: BorrowingRequestDetail) {
        // Basic info
        binding.tvRequestId.text = request.formatted_id
        binding.tvSubject.text = request.subject
        binding.tvStatus.text = request.status
        binding.tvPurpose.text = request.purpose ?: "Not specified"
        binding.tvRoomNumber.text = request.room_number ?: "Not specified"
        binding.tvInstructorName.text = request.instructor_name ?: "Not specified"
        
        // Dates and times
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        
        binding.tvScheduledDate.text = request.scheduled_date?.let { dateFormat.format(it) } ?: "Not set"
        binding.tvStartTime.text = request.start_time ?: "Not set"
        binding.tvEndTime.text = request.end_time ?: "Not set"
        binding.tvCreatedAt.text = request.created_at?.let { dateFormat.format(it) } ?: "Unknown"
        
        // Status-specific info
        when (request.status.lowercase()) {
            "approved" -> {
                binding.tvApprovedBy.text = request.approved_by_name ?: "Unknown"
                binding.tvApprovedAt.text = request.approved_at?.let { dateFormat.format(it) } ?: "Unknown"
                binding.layoutApprovalInfo.visibility = View.VISIBLE
            }
            "rejected" -> {
                binding.tvRejectionReason.text = request.rejection_reason ?: "No reason provided"
                binding.layoutRejectionInfo.visibility = View.VISIBLE
            }
            "returned" -> {
                binding.tvReturnedAt.text = request.returned_at?.let { dateFormat.format(it) } ?: "Unknown"
                binding.layoutReturnInfo.visibility = View.VISIBLE
            }
        }
        
        // Admin notes
        if (!request.admin_notes.isNullOrEmpty()) {
            binding.tvAdminNotes.text = request.admin_notes
            binding.layoutAdminNotes.visibility = View.VISIBLE
        }
        
        // Set status color
        setStatusColor(request.status)
        
        // Update items list
        requestItemsAdapter.updateItems(request.items)
        
        // Show action buttons based on status
        setupActionButtons(request)
    }

    private fun setStatusColor(status: String) {
        val colorRes = when (status.lowercase()) {
            "pending" -> R.color.status_pending
            "approved" -> R.color.status_approved
            "released" -> R.color.status_released
            "returned" -> R.color.status_returned
            "rejected" -> R.color.status_rejected
            "overdue" -> R.color.status_overdue
            else -> R.color.text_secondary
        }
        
        binding.tvStatus.setTextColor(getColor(colorRes))
    }

    private fun setupActionButtons(request: BorrowingRequestDetail) {
        binding.layoutActions.visibility = View.GONE
        
        when (request.status.lowercase()) {
            "pending" -> {
                binding.btnCancelRequest.visibility = View.VISIBLE
                binding.btnCancelRequest.setOnClickListener {
                    showCancelDialog()
                }
                binding.layoutActions.visibility = View.VISIBLE
            }
            "approved", "released" -> {
                // No actions available for students
                binding.layoutActions.visibility = View.GONE
            }
        }
    }

    private fun showCancelDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Cancel Request")
            .setMessage("Are you sure you want to cancel this borrowing request? This action cannot be undone.")
            .setPositiveButton("Cancel Request") { _, _ ->
                cancelRequest()
            }
            .setNegativeButton("Keep Request", null)
            .show()
    }

    private fun cancelRequest() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(this, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.requestService.cancelRequest(token, requestId)

                if (response.success) {
                    Toast.makeText(this@RequestDetailActivity, "Request cancelled successfully", Toast.LENGTH_SHORT).show()
                    loadRequestDetail() // Refresh the details
                } else {
                    Toast.makeText(this@RequestDetailActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RequestDetailActivity, "Failed to cancel request: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
