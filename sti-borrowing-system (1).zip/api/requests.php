<?php
require_once 'config.php';

$user = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getRequest($_GET['id'], $user);
        } else {
            getRequests($user);
        }
        break;
    
    case 'POST':
        createRequest($user);
        break;
    
    default:
        sendResponse(false, 'Method not allowed', null, 405);
}

function getRequests($user) {
    global $pdo;
    
    try {
        if ($user['user_type'] == 'Borrower') {
            $stmt = $pdo->prepare("
                SELECT br.*, 
                       GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list,
                       COUNT(ri.request_item_id) as item_count
                FROM borrowing_requests br
                LEFT JOIN request_items ri ON br.request_id = ri.request_id
                LEFT JOIN items i ON ri.item_id = i.item_id
                WHERE br.requester_id = ? AND br.archived = FALSE
                GROUP BY br.request_id
                ORDER BY br.created_at DESC
                LIMIT 50
            ");
            $stmt->execute([$user['user_id']]);
        } else {
            $stmt = $pdo->prepare("
                SELECT br.*, 
                       u.first_name, u.last_name, u.id_number,
                       GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list,
                       COUNT(ri.request_item_id) as item_count
                FROM borrowing_requests br
                JOIN users u ON br.requester_id = u.user_id
                LEFT JOIN request_items ri ON br.request_id = ri.request_id
                LEFT JOIN items i ON ri.item_id = i.item_id
                WHERE br.archived = FALSE
                GROUP BY br.request_id
                ORDER BY br.created_at DESC
                LIMIT 100
            ");
            $stmt->execute();
        }
        
        $requests = $stmt->fetchAll();
        sendResponse(true, 'Requests retrieved successfully', $requests);
        
    } catch (PDOException $e) {
        sendResponse(false, 'Failed to retrieve requests', null, 500);
    }
}

function getRequest($request_id, $user) {
    global $pdo;
    
    try {
        // Get request details
        $stmt = $pdo->prepare("
            SELECT br.*, 
                   requester.first_name as requester_first_name, 
                   requester.last_name as requester_last_name,
                   requester.id_number as requester_id_number,
                   approver.first_name as approver_first_name, 
                   approver.last_name as approver_last_name
            FROM borrowing_requests br
            JOIN users requester ON br.requester_id = requester.user_id
            LEFT JOIN users approver ON br.approved_by = approver.user_id
            WHERE br.request_id = ? AND br.archived = FALSE
        ");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch();
        
        if (!$request) {
            sendResponse(false, 'Request not found', null, 404);
        }
        
        // Check permissions
        if ($user['user_type'] == 'Borrower' && $request['requester_id'] != $user['user_id']) {
            sendResponse(false, 'Access denied', null, 403);
        }
        
        // Get request items
        $stmt = $pdo->prepare("
            SELECT ri.*, i.item_name, i.item_code, i.description
            FROM request_items ri
            JOIN items i ON ri.item_id = i.item_id
            WHERE ri.request_id = ?
            ORDER BY i.item_name
        ");
        $stmt->execute([$request_id]);
        $request_items = $stmt->fetchAll();
        
        $request['items'] = $request_items;
        
        sendResponse(true, 'Request retrieved successfully', $request);
        
    } catch (PDOException $e) {
        sendResponse(false, 'Failed to retrieve request', null, 500);
    }
}

function createRequest($user) {
    global $pdo;
    
    if ($user['user_type'] != 'Borrower') {
        sendResponse(false, 'Only borrowers can create requests', null, 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['subject']) || !isset($input['scheduled_date']) || !isset($input['items'])) {
        sendResponse(false, 'Subject, scheduled date, and items are required', null, 400);
    }
    
    if (empty($input['items'])) {
        sendResponse(false, 'At least one item must be selected', null, 400);
    }
    
    try {
        $pdo->beginTransaction();
        
        // Create the borrowing request
        $stmt = $pdo->prepare("
            INSERT INTO borrowing_requests (requester_id, subject, description, scheduled_date) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $user['user_id'], 
            $input['subject'], 
            $input['description'] ?? '', 
            $input['scheduled_date']
        ]);
        $request_id = $pdo->lastInsertId();
        
        // Add requested items
        foreach ($input['items'] as $item) {
            if ($item['quantity'] > 0) {
                $stmt = $pdo->prepare("
                    INSERT INTO request_items (request_id, item_id, quantity_requested) 
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([$request_id, $item['item_id'], $item['quantity']]);
                
                // Update item availability
                updateItemAvailability($item['item_id']);
            }
        }
        
        $pdo->commit();
        
        // Log activity
        logActivity($user['user_id'], 'Mobile Create Request', "Created borrowing request #$request_id via mobile app");
        
        // Notify custodians
        $custodians_stmt = $pdo->prepare("SELECT user_id FROM users WHERE user_type = 'Custodian' AND archived = FALSE");
        $custodians_stmt->execute();
        $custodians = $custodians_stmt->fetchAll();
        
        foreach ($custodians as $custodian) {
            createNotification(
                $custodian['user_id'], 
                "New mobile request #$request_id from " . $user['first_name'] . " " . $user['last_name'],
                'Info'
            );
        }
        
        sendResponse(true, 'Request created successfully', [
            'request_id' => $request_id,
            'formatted_id' => str_pad($request_id, 4, '0', STR_PAD_LEFT)
        ]);
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        sendResponse(false, 'Failed to create request', null, 500);
    }
}
?>
