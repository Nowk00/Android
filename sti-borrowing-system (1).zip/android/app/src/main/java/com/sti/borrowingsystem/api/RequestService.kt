package com.sti.borrowingsystem.api

import com.sti.borrowingsystem.models.*
import retrofit2.http.*

interface RequestService {
    @GET("requests.php")
    suspend fun getRequests(@Header("Authorization") token: String): ApiResponse<List<BorrowingRequest>>
    
    @GET("requests.php")
    suspend fun getRequest(
        @Header("Authorization") token: String,
        @Query("id") requestId: Int
    ): ApiResponse<BorrowingRequestDetail>
    
    @POST("requests.php")
    suspend fun createRequest(
        @Header("Authorization") token: String,
        @Body request: CreateRequestRequest
    ): ApiResponse<CreateRequestResponse>
}
