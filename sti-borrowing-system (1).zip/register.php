<?php
require_once 'config/functions.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_number = sanitizeInput($_POST['student_number']);
    $last_name = sanitizeInput($_POST['last_name']);
    $first_name = sanitizeInput($_POST['first_name']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    if (empty($student_number) || empty($last_name) || empty($first_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error_message = 'Please fill in all fields.';
    } elseif (!preg_match('/^\d{6}$/', $student_number)) {
        $error_message = 'Student number must be exactly 6 digits.';
    } elseif (strlen($password) < 6) {
        $error_message = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirm_password) {
        $error_message = 'Passwords do not match.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        try {
            // Generate ID number in format: lastname.studentnumber
            $id_number = strtolower($last_name) . '.' . $student_number;
            
            // Check if ID number already exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE id_number = ?");
            $stmt->execute([$id_number]);
            if ($stmt->fetchColumn() > 0) {
                $error_message = 'An account with this student number and last name already exists.';
            } else {
                // Check if email already exists
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetchColumn() > 0) {
                    $error_message = 'An account with this email address already exists.';
                } else {
                    // Create new user account
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO users (id_number, first_name, last_name, email, password, user_type) 
                        VALUES (?, ?, ?, ?, ?, 'Borrower')
                    ");
                    $stmt->execute([$id_number, $first_name, $last_name, $email, $hashed_password]);
                    
                    $user_id = $pdo->lastInsertId();
                    
                    // Log the registration activity
                    logActivity($user_id, 'Registration', 'New user account created');
                    
                    // Create welcome notification
                    createNotification(
                        $user_id, 
                        "Welcome to STI Borrowing System! Your account has been successfully created.",
                        'Success'
                    );
                    
                    $success_message = "Registration successful! Your ID number is: <strong>$id_number</strong><br>You can now login with this ID number and your password.";
                }
            }
        } catch(PDOException $e) {
            $error_message = 'Registration failed. Please try again.';
            error_log("Registration error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - STI College Balagtas Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="register-page">
    <div class="register-container">
        <div class="register-box">
            <div class="register-header">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <h1>STI College Balagtas</h1>
                <h2>Student Registration</h2>
            </div>
            
            <?php if ($success_message): ?>
                <div class="alert alert-success" style="margin: 20px;">
                    <?php echo $success_message; ?>
                </div>
                <div class="register-footer">
                    <p><a href="index.php">← Back to Login</a></p>
                </div>
            <?php else: ?>
                <?php if ($error_message): ?>
                    <div class="alert alert-error" style="margin: 20px 20px 0 20px;">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" class="register-form">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="student_number">Student Number:</label>
                                <input type="text" id="student_number" name="student_number" required 
                                       pattern="[0-9]{6}" maxlength="6" placeholder="230575"
                                       value="<?php echo isset($_POST['student_number']) ? htmlspecialchars($_POST['student_number']) : ''; ?>">
                                <div class="help-text">Enter your 6-digit student number</div>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="last_name">Last Name:</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       placeholder="Borja"
                                       value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
                                <div class="help-text">Enter your family name</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="example-text">
                        <strong>Your ID will be:</strong> <span id="preview-id">lastname.studentnumber</span>
                        <br><small>Example: borja.230575</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="first_name">First Name:</label>
                        <input type="text" id="first_name" name="first_name" required 
                               placeholder="Juan"
                               value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email" id="email" name="email" required 
                               placeholder="juan.borja@sti.edu.ph"
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" id="password" name="password" required minlength="6">
                                <div class="help-text">At least 6 characters</div>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password:</label>
                                <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                                <div class="help-text">Re-enter your password</div>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-login">Register Account</button>
                </form>
                
                <div class="register-footer">
                    <p>Already have an account? <a href="index.php">Login here</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Live preview of ID number
        function updatePreview() {
            const studentNumber = document.getElementById('student_number').value;
            const lastName = document.getElementById('last_name').value.toLowerCase();
            const preview = document.getElementById('preview-id');
            
            if (lastName && studentNumber) {
                preview.textContent = lastName + '.' + studentNumber;
                preview.style.fontWeight = 'bold';
                preview.style.color = '#667eea';
            } else {
                preview.textContent = 'lastname.studentnumber';
                preview.style.fontWeight = 'normal';
                preview.style.color = '#666';
            }
        }
        
        document.getElementById('student_number').addEventListener('input', updatePreview);
        document.getElementById('last_name').addEventListener('input', updatePreview);
        
        // Password confirmation validation
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (password !== confirmPassword) {
                this.setCustomValidity('Passwords do not match');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Student number validation (numbers only)
        document.getElementById('student_number').addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
        
        // Last name validation (letters only)
        document.getElementById('last_name').addEventListener('input', function() {
            this.value = this.value.replace(/[^a-zA-Z]/g, '');
        });
    </script>
</body>
</html>
