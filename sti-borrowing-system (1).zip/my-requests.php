<?php
require_once 'config/functions.php';
requireUserType(['Borrower']);

$user_info = getUserInfo($_SESSION['user_id']);

// Get user's requests
try {
    $stmt = $pdo->prepare("
        SELECT br.*, 
               GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list,
               COUNT(ri.request_item_id) as item_count
        FROM borrowing_requests br
        LEFT JOIN request_items ri ON br.request_id = ri.request_id
        LEFT JOIN items i ON ri.item_id = i.item_id
        WHERE br.requester_id = ? AND br.archived = FALSE
        GROUP BY br.request_id
        ORDER BY br.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $requests = $stmt->fetchAll();
} catch(PDOException $e) {
    $requests = [];
    $error_message = 'Failed to load your requests.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Requests - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create-request.php">Create Request</a></li>
                <li><a href="my-requests.php" class="active">My Requests</a></li>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>My Borrowing Requests</h1>
            <p>View and track all your borrowing requests.</p>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Request History</h3>
            </div>
            <div class="card-body">
                <?php if (empty($requests)): ?>
                    <p>You haven't submitted any borrowing requests yet.</p>
                    <a href="create-request.php" class="btn btn-primary">Create Your First Request</a>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Subject</th>
                                    <th>Items</th>
                                    <th>Scheduled Date</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requests as $request): ?>
                                <tr>
                                    <td>#<?php echo str_pad($request['request_id'], 4, '0', STR_PAD_LEFT); ?></td>
                                    <td><?php echo htmlspecialchars($request['subject']); ?></td>
                                    <td>
                                        <small><?php echo htmlspecialchars($request['items_list'] ?: 'No items'); ?></small>
                                        <br><span class="text-muted"><?php echo $request['item_count']; ?> item(s)</span>
                                    </td>
                                    <td><?php echo formatDate($request['scheduled_date']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                                            <?php echo $request['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatDate($request['created_at']); ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view-request.php?id=<?php echo $request['request_id']; ?>" class="btn btn-info btn-sm">View</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</body>
</html>
