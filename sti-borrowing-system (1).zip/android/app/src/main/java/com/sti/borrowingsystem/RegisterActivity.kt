package com.sti.borrowingsystem

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityRegisterBinding
import com.sti.borrowingsystem.models.RegisterRequest
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupToolbar()
        setupSpinners()
        setupClickListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Register Account"
    }

    private fun setupSpinners() {
        // Department spinner
        val departments = arrayOf(
            "College of Computer Studies",
            "College of Business Administration", 
            "College of Arts and Sciences",
            "College of Engineering",
            "College of Education"
        )
        val departmentAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, departments)
        binding.spinnerDepartment.adapter = departmentAdapter

        // Course spinner
        val courses = arrayOf(
            "Bachelor of Science in Information Technology",
            "Bachelor of Science in Computer Science",
            "Bachelor of Science in Business Administration",
            "Bachelor of Science in Accountancy",
            "Bachelor of Elementary Education",
            "Bachelor of Secondary Education"
        )
        val courseAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, courses)
        binding.spinnerCourse.adapter = courseAdapter

        // Year Level spinner
        val yearLevels = arrayOf("1st Year", "2nd Year", "3rd Year", "4th Year")
        val yearAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, yearLevels)
        binding.spinnerYearLevel.adapter = yearAdapter
    }

    private fun setupClickListeners() {
        binding.btnRegister.setOnClickListener {
            performRegistration()
        }
        
        binding.tvLogin.setOnClickListener {
            finish() // Go back to login
        }
    }

    private fun performRegistration() {
        val idNumber = binding.etIdNumber.text.toString().trim()
        val firstName = binding.etFirstName.text.toString().trim()
        val lastName = binding.etLastName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()
        val department = binding.spinnerDepartment.selectedItem.toString()
        val course = binding.spinnerCourse.selectedItem.toString()
        val yearLevel = binding.spinnerYearLevel.selectedItemPosition + 1

        // Validation
        if (idNumber.isEmpty()) {
            binding.etIdNumber.error = "ID Number is required"
            binding.etIdNumber.requestFocus()
            return
        }

        if (firstName.isEmpty()) {
            binding.etFirstName.error = "First name is required"
            binding.etFirstName.requestFocus()
            return
        }

        if (lastName.isEmpty()) {
            binding.etLastName.error = "Last name is required"
            binding.etLastName.requestFocus()
            return
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Valid email is required"
            binding.etEmail.requestFocus()
            return
        }

        if (phone.isEmpty()) {
            binding.etPhone.error = "Phone number is required"
            binding.etPhone.requestFocus()
            return
        }

        if (password.isEmpty() || password.length < 6) {
            binding.etPassword.error = "Password must be at least 6 characters"
            binding.etPassword.requestFocus()
            return
        }

        if (password != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"
            binding.etConfirmPassword.requestFocus()
            return
        }

        showLoading(true)

        lifecycleScope.launch {
            try {
                val registerRequest = RegisterRequest(
                    action = "register",
                    id_number = idNumber,
                    first_name = firstName,
                    last_name = lastName,
                    email = email,
                    phone = phone,
                    password = password,
                    department = department,
                    course = course,
                    year_level = yearLevel
                )

                val response = ApiClient.authService.register(registerRequest)

                if (response.success) {
                    androidx.appcompat.app.AlertDialog.Builder(this@RegisterActivity)
                        .setTitle("Registration Successful")
                        .setMessage("Your account has been created successfully! You can now login with your credentials.")
                        .setPositiveButton("OK") { _, _ ->
                            finish()
                        }
                        .setCancelable(false)
                        .show()
                } else {
                    Toast.makeText(this@RegisterActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@RegisterActivity, "Registration failed: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                showLoading(false)
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnRegister.isEnabled = !show
        
        if (show) {
            binding.btnRegister.text = "Creating Account..."
        } else {
            binding.btnRegister.text = "Register"
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
