<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($input['action'])) {
            sendResponse(false, 'Action required', null, 400);
        }
        
        switch ($input['action']) {
            case 'login':
                login($input);
                break;
            case 'register':
                register($input);
                break;
            default:
                sendResponse(false, 'Invalid action', null, 400);
        }
        break;
    
    default:
        sendResponse(false, 'Method not allowed', null, 405);
}

function login($input) {
    global $pdo;
    
    if (!isset($input['id_number']) || !isset($input['password'])) {
        sendResponse(false, 'ID number and password required', null, 400);
    }
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id_number = ? AND archived = FALSE");
        $stmt->execute([$input['id_number']]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($input['password'], $user['password'])) {
            $token = generateToken($user);
            
            // Log activity
            logActivity($user['user_id'], 'Mobile Login', 'User logged in via mobile app');
            
            sendResponse(true, 'Login successful', [
                'token' => $token,
                'user' => [
                    'user_id' => $user['user_id'],
                    'id_number' => $user['id_number'],
                    'first_name' => $user['first_name'],
                    'last_name' => $user['last_name'],
                    'email' => $user['email'],
                    'user_type' => $user['user_type']
                ]
            ]);
        } else {
            sendResponse(false, 'Invalid credentials', null, 401);
        }
    } catch (PDOException $e) {
        sendResponse(false, 'Login failed', null, 500);
    }
}

function register($input) {
    global $pdo;
    
    $required = ['student_number', 'last_name', 'first_name', 'email', 'password'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            sendResponse(false, "Field $field is required", null, 400);
        }
    }
    
    if (!preg_match('/^\d{6}$/', $input['student_number'])) {
        sendResponse(false, 'Student number must be exactly 6 digits', null, 400);
    }
    
    if (strlen($input['password']) < 6) {
        sendResponse(false, 'Password must be at least 6 characters', null, 400);
    }
    
    try {
        $id_number = strtolower($input['last_name']) . '.' . $input['student_number'];
        
        // Check if user exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE id_number = ? OR email = ?");
        $stmt->execute([$id_number, $input['email']]);
        if ($stmt->fetchColumn() > 0) {
            sendResponse(false, 'User already exists', null, 409);
        }
        
        $hashed_password = password_hash($input['password'], PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (id_number, first_name, last_name, email, password, user_type) 
            VALUES (?, ?, ?, ?, ?, 'Borrower')
        ");
        $stmt->execute([
            $id_number, 
            $input['first_name'], 
            $input['last_name'], 
            $input['email'], 
            $hashed_password
        ]);
        
        $user_id = $pdo->lastInsertId();
        
        logActivity($user_id, 'Mobile Registration', 'New user registered via mobile app');
        createNotification($user_id, 'Welcome to STI Borrowing System!', 'Success');
        
        sendResponse(true, 'Registration successful', [
            'id_number' => $id_number,
            'message' => 'You can now login with your ID number and password'
        ]);
        
    } catch (PDOException $e) {
        sendResponse(false, 'Registration failed', null, 500);
    }
}
?>
