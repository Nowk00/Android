package com.sti.borrowingsystem

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityLoginBinding
import com.sti.borrowingsystem.models.LoginRequest
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        
        // Check if already logged in
        if (sessionManager.isLoggedIn()) {
            startMainActivity()
            return
        }
        
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnLogin.setOnClickListener {
            performLogin()
        }
        
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        
        binding.tvForgotPassword.setOnClickListener {
            showForgotPasswordDialog()
        }
    }

    private fun performLogin() {
        val idNumber = binding.etIdNumber.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        
        if (idNumber.isEmpty()) {
            binding.etIdNumber.error = "ID Number is required"
            binding.etIdNumber.requestFocus()
            return
        }
        
        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            binding.etPassword.requestFocus()
            return
        }
        
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val loginRequest = LoginRequest(
                    action = "login",
                    id_number = idNumber,
                    password = password
                )
                
                val response = ApiClient.authService.login(loginRequest)
                
                if (response.success) {
                    // Check if user is a borrower
                    if (response.data.user.user_type != "Borrower") {
                        Toast.makeText(this@LoginActivity, 
                            "This app is only for borrowers. Please use the web system.", 
                            Toast.LENGTH_LONG).show()
                        showLoading(false)
                        return@launch
                    }
                    
                    // Save session
                    sessionManager.saveSession(response.data.token, response.data.user)
                    
                    Toast.makeText(this@LoginActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                    startMainActivity()
                } else {
                    Toast.makeText(this@LoginActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Login failed: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                showLoading(false)
            }
        }
    }

    private fun showForgotPasswordDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Forgot Password")
            .setMessage("Please contact your administrator or custodian to reset your password.\n\nEmail: admin@stibalagtas.edu.ph\nPhone: (044) 123-4567")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !show
        binding.etIdNumber.isEnabled = !show
        binding.etPassword.isEnabled = !show
        binding.tvRegister.isEnabled = !show
        
        if (show) {
            binding.btnLogin.text = "Logging in..."
        } else {
            binding.btnLogin.text = "Login"
        }
    }

    private fun startMainActivity() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
