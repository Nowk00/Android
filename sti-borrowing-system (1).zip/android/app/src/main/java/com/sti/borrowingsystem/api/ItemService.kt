package com.sti.borrowingsystem.api

import com.sti.borrowingsystem.models.*
import retrofit2.http.*

interface ItemService {
    @GET("items.php")
    suspend fun getItems(
        @Header("Authorization") token: String,
        @Query("search") search: String? = null,
        @Query("condition") condition: String? = null,
        @Query("available_only") availableOnly: Boolean? = null
    ): ApiResponse<List<Item>>
}
