package com.sti.borrowingsystem

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.sti.borrowingsystem.databinding.ActivityMainBinding
import com.sti.borrowingsystem.fragments.BrowseItemsFragment
import com.sti.borrowingsystem.fragments.DashboardFragment
import com.sti.borrowingsystem.fragments.MyRequestsFragment
import com.sti.borrowingsystem.fragments.ProfileFragment
import com.sti.borrowingsystem.utils.SessionManager

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        
        // Check if user is logged in
        if (!sessionManager.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        
        setupNavigation()
        setupUserInfo()
        
        // Load default fragment
        if (savedInstanceState == null) {
            loadFragment(DashboardFragment())
            binding.bottomNavigation.selectedItemId = R.id.navigation_dashboard
        }
    }

    private fun setupNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_dashboard -> {
                    loadFragment(DashboardFragment())
                    true
                }
                R.id.navigation_my_requests -> {
                    loadFragment(MyRequestsFragment())
                    true
                }
                R.id.navigation_browse_items -> {
                    loadFragment(BrowseItemsFragment())
                    true
                }
                R.id.navigation_profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun setupUserInfo() {
        val user = sessionManager.getUser()
        user?.let {
            supportActionBar?.subtitle = "${it.first_name} ${it.last_name} (${it.id_number})"
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                showLogoutDialog()
                true
            }
            R.id.action_refresh -> {
                // Refresh current fragment
                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
                currentFragment?.let {
                    when (it) {
                        is DashboardFragment -> it.refreshData()
                        is MyRequestsFragment -> it.refreshData()
                        is BrowseItemsFragment -> it.refreshData()
                        is ProfileFragment -> it.refreshData()
                    }
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showLogoutDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout") { _, _ ->
                logout()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun logout() {
        sessionManager.clearSession()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
