package com.sti.borrowingsystem.api

import com.sti.borrowingsystem.models.*
import retrofit2.http.*

interface DashboardService {
    @GET("dashboard.php")
    suspend fun getDashboardData(@Header("Authorization") token: String): ApiResponse<DashboardData>
}
