package com.sti.borrowingsystem.api

import com.sti.borrowingsystem.models.*
import retrofit2.http.Body
import retrofit2.http.POST

interface AuthService {
    @POST("auth.php")
    suspend fun login(@Body request: LoginRequest): ApiResponse<LoginResponse>
    
    @POST("auth.php")
    suspend fun register(@Body request: RegisterRequest): ApiResponse<RegisterResponse>
}
