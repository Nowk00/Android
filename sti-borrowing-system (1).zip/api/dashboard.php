<?php
require_once 'config.php';

$user = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        getDashboardData($user);
        break;
    
    default:
        sendResponse(false, 'Method not allowed', null, 405);
}

function getDashboardData($user) {
    global $pdo;
    
    try {
        $data = [];
        
        if ($user['user_type'] == 'Borrower') {
            // Get user's request statistics
            $stmt = $pdo->prepare("
                SELECT 
                    COUNT(*) as total_requests,
                    COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_requests,
                    COUNT(CASE WHEN status = 'Approved' THEN 1 END) as approved_requests,
                    COUNT(CASE WHEN status = 'Completed' THEN 1 END) as completed_requests
                FROM borrowing_requests 
                WHERE requester_id = ? AND archived = FALSE
            ");
            $stmt->execute([$user['user_id']]);
            $data['user_stats'] = $stmt->fetch();
            
            // Get recent requests
            $stmt = $pdo->prepare("
                SELECT br.*, 
                       GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list
                FROM borrowing_requests br
                LEFT JOIN request_items ri ON br.request_id = ri.request_id
                LEFT JOIN items i ON ri.item_id = i.item_id
                WHERE br.requester_id = ? AND br.archived = FALSE
                GROUP BY br.request_id
                ORDER BY br.created_at DESC
                LIMIT 5
            ");
            $stmt->execute([$user['user_id']]);
            $data['recent_requests'] = $stmt->fetchAll();
            
        } else {
            // Get system statistics for custodians/admins
            $stmt = $pdo->prepare("
                SELECT 
                    COUNT(*) as total_requests,
                    COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_requests,
                    COUNT(CASE WHEN status = 'Approved' THEN 1 END) as approved_requests,
                    COUNT(CASE WHEN status = 'Completed' THEN 1 END) as completed_requests
                FROM borrowing_requests 
                WHERE archived = FALSE
            ");
            $stmt->execute();
            $data['system_stats'] = $stmt->fetch();
            
            // Get recent requests
            $stmt = $pdo->prepare("
                SELECT br.*, u.first_name, u.last_name,
                       GROUP_CONCAT(CONCAT(i.item_name, ' (', ri.quantity_requested, ')') SEPARATOR ', ') as items_list
                FROM borrowing_requests br
                JOIN users u ON br.requester_id = u.user_id
                LEFT JOIN request_items ri ON br.request_id = ri.request_id
                LEFT JOIN items i ON ri.item_id = i.item_id
                WHERE br.archived = FALSE
                GROUP BY br.request_id
                ORDER BY br.created_at DESC
                LIMIT 10
            ");
            $stmt->execute();
            $data['recent_requests'] = $stmt->fetchAll();
        }
        
        // Get notifications
        $stmt = $pdo->prepare("
            SELECT * FROM notifications 
            WHERE user_id = ? AND is_read = FALSE 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stmt->execute([$user['user_id']]);
        $data['notifications'] = $stmt->fetchAll();
        
        sendResponse(true, 'Dashboard data retrieved successfully', $data);
        
    } catch (PDOException $e) {
        sendResponse(false, 'Failed to retrieve dashboard data', null, 500);
    }
}
?>
