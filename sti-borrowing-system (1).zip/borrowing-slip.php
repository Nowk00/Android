<?php
require_once 'config/functions.php';
requireLogin();

$request_id = $_GET['id'] ?? 0;
$slip_type = $_GET['type'] ?? 'equipment'; // equipment, laboratory

if (!$request_id) {
    header("Location: dashboard.php");
    exit();
}

// Get request details
try {
    $stmt = $pdo->prepare("
        SELECT br.*, 
               requester.first_name as requester_first_name, 
               requester.last_name as requester_last_name,
               requester.id_number as requester_id_number,
               requester.department as requester_department,
               approver.first_name as approver_first_name, 
               approver.last_name as approver_last_name,
               r.room_name, r.room_type
        FROM borrowing_requests br
        JOIN users requester ON br.requester_id = requester.user_id
        LEFT JOIN users approver ON br.approved_by = approver.user_id
        LEFT JOIN rooms r ON br.room_id = r.room_id
        WHERE br.request_id = ? AND br.archived = FALSE
    ");
    $stmt->execute([$request_id]);
    $request = $stmt->fetch();
    
    if (!$request) {
        header("Location: dashboard.php");
        exit();
    }
    
    // Get request items
    $stmt = $pdo->prepare("
        SELECT ri.*, i.item_name, i.item_code, i.description
        FROM request_items ri
        JOIN items i ON ri.item_id = i.item_id
        WHERE ri.request_id = ?
        ORDER BY i.item_name
    ");
    $stmt->execute([$request_id]);
    $request_items = $stmt->fetchAll();
    
    // Get group members for laboratory requests
    $group_members = [];
    if ($request['request_type'] == 'laboratory') {
        $stmt = $pdo->prepare("
            SELECT member_name FROM request_group_members 
            WHERE request_id = ? 
            ORDER BY member_id
        ");
        $stmt->execute([$request_id]);
        $group_members = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
} catch(PDOException $e) {
    header("Location: dashboard.php");
    exit();
}

$slip_type = $request['request_type'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ucfirst($slip_type); ?> Borrowing Slip - STI Borrowing System</title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            .slip-container { box-shadow: none; margin: 0; }
        }
        
        body {
            font-family: 'Courier New', monospace;
            margin: 20px;
            background: #f5f5f5;
        }
        
        .slip-container {
            background: white;
            max-width: 800px;
            margin: 0 auto;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            border: 2px solid #000;
        }
        
        .slip-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #000;
            padding-bottom: 15px;
        }
        
        .college-name {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .slip-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .slip-info {
            display: flex;
            justify-content: space-between;
            margin: 20px 0;
            font-size: 14px;
        }
        
        .info-section {
            flex: 1;
        }
        
        .info-row {
            margin: 8px 0;
            display: flex;
            align-items: center;
        }
        
        .info-label {
            font-weight: bold;
            min-width: 120px;
            margin-right: 10px;
        }
        
        .info-value {
            border-bottom: 1px solid #000;
            flex: 1;
            padding: 2px 5px;
            min-height: 20px;
        }
        
        .slip-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 12px;
        }
        
        .slip-table th,
        .slip-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        
        .slip-table th {
            background: #f0f0f0;
            font-weight: bold;
            text-align: center;
        }
        
        .group-members {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin: 20px 0;
        }
        
        .member-row {
            display: flex;
            align-items: center;
            margin: 5px 0;
        }
        
        .member-number {
            font-weight: bold;
            min-width: 25px;
        }
        
        .member-name {
            border-bottom: 1px solid #000;
            flex: 1;
            padding: 2px 5px;
            margin-left: 10px;
        }
        
        .signatures {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature-section {
            text-align: center;
            flex: 1;
            margin: 0 20px;
        }
        
        .signature-line {
            border-bottom: 1px solid #000;
            margin: 30px 0 10px 0;
            height: 40px;
        }
        
        .signature-label {
            font-size: 12px;
            font-weight: bold;
        }
        
        .print-btn {
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px 0;
            font-size: 14px;
        }
        
        .back-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin: 20px 10px 20px 0;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        
        .status-info {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #2196f3;
        }
        
        .date-time-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 1fr;
            gap: 20px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="no-print">
        <a href="javascript:history.back()" class="back-btn">← Back</a>
        <button onclick="window.print()" class="print-btn">🖨️ Print Slip</button>
    </div>

    <div class="slip-container">
        <?php if ($slip_type == 'equipment'): ?>
            <!-- Equipment Borrowing Slip -->
            <div class="slip-header">
                <div class="college-name">STI COLLEGE BALAGTAS</div>
                <div>Mc Arthur Hi-way, Brgy. Wawa, Balagtas, Bulacan</div>
                <div class="slip-title">Borrower's Slip</div>
            </div>

            <div class="slip-info">
                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">Name of Borrower:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['requester_first_name'] . ' ' . $request['requester_last_name']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Department:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['requester_department'] ?: $request['purpose']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Purpose:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['subject']); ?></span>
                    </div>
                </div>
                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">Date:</span>
                        <span class="info-value"><?php echo formatDate($request['scheduled_date']); ?></span>
                    </div>
                </div>
            </div>

            <table class="slip-table">
                <thead>
                    <tr>
                        <th>Item / Description</th>
                        <th>Quantity</th>
                        <th>Schedule</th>
                        <th>Date Released</th>
                        <th>Time Released</th>
                        <th>Date Returned</th>
                        <th>Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($request_items as $item): ?>
                    <tr>
                        <td>
                            <strong><?php echo htmlspecialchars($item['item_name']); ?></strong>
                            <?php if ($item['description']): ?>
                                <br><small><?php echo htmlspecialchars($item['description']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: center;"><?php echo $item['quantity_requested']; ?></td>
                        <td>
                            <?php echo formatDate($request['scheduled_date']); ?>
                            <?php if ($request['start_time'] && $request['end_time']): ?>
                                <br><?php echo date('g:i A', strtotime($request['start_time'])); ?> - <?php echo date('g:i A', strtotime($request['end_time'])); ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $item['issued_date'] ? formatDate($item['issued_date']) : ''; ?></td>
                        <td><?php echo $item['issued_date'] ? date('g:i A', strtotime($item['issued_date'])) : ''; ?></td>
                        <td><?php echo $item['returned_date'] ? formatDate($item['returned_date']) : ''; ?></td>
                        <td></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Add empty rows for manual entries -->
                    <?php for ($i = count($request_items); $i < 8; $i++): ?>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
            </table>

            <div class="signatures">
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-label">Signature of Borrower</div>
                </div>
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-label">Released by</div>
                </div>
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-label">Received by</div>
                </div>
            </div>

            <div style="margin-top: 30px; text-align: center; font-size: 12px;">
                <div style="margin-bottom: 20px;">
                    <div class="signature-line" style="width: 300px; margin: 0 auto;"></div>
                    <div class="signature-label">Property and Equipment Custodian</div>
                </div>
            </div>

        <?php elseif ($slip_type == 'laboratory'): ?>
            <!-- Laboratory Request Form -->
            <div class="slip-header">
                <div class="college-name">STI COLLEGE BALAGTAS HM</div>
                <div class="slip-title">LABORATORY REQUEST FORM</div>
                <div style="margin-top: 15px;">
                    <strong>GROUP NO: <?php echo htmlspecialchars($request['group_number'] ?: '____'); ?></strong>
                </div>
            </div>

            <div style="margin: 20px 0; font-weight: bold; text-align: center; border: 1px solid #000; padding: 10px;">
                GROUP MEMBERS (BORROWER/S)
            </div>

            <div class="group-members">
                <?php 
                $max_members = max(8, count($group_members));
                for ($i = 0; $i < $max_members; $i++): 
                    $member_name = isset($group_members[$i]) ? $group_members[$i] : '';
                ?>
                <div class="member-row">
                    <span class="member-number"><?php echo ($i + 1); ?>.</span>
                    <span class="member-name"><?php echo htmlspecialchars($member_name); ?></span>
                </div>
                <?php endfor; ?>
            </div>

            <div class="date-time-grid">
                <div class="info-row">
                    <span class="info-label">SUBJECT:</span>
                    <span class="info-value"><?php echo htmlspecialchars($request['subject']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">DATE:</span>
                    <span class="info-value"><?php echo formatDate($request['scheduled_date']); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">TIME:</span>
                    <span class="info-value"><?php echo $request['start_time'] ? date('g:i A', strtotime($request['start_time'])) : ''; ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">DAY:</span>
                    <span class="info-value"><?php echo htmlspecialchars($request['day_of_week']); ?></span>
                </div>
            </div>

            <div class="info-row" style="margin: 20px 0;">
                <span class="info-label">SECTION & BATCH:</span>
                <span class="info-value"><?php echo htmlspecialchars($request['section_batch']); ?></span>
            </div>

            <table class="slip-table">
                <thead>
                    <tr>
                        <th rowspan="2">DESCRIPTION</th>
                        <th colspan="2">REQUESTED</th>
                        <th colspan="2">ISSUED</th>
                        <th colspan="2">RETURNED</th>
                        <th rowspan="2">REMARKS</th>
                    </tr>
                    <tr>
                        <th>QTY.</th>
                        <th>UNIT</th>
                        <th>QTY.</th>
                        <th>UNIT</th>
                        <th>QTY.</th>
                        <th>UNIT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($request_items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                        <td style="text-align: center;"><?php echo $item['quantity_requested']; ?></td>
                        <td style="text-align: center;">pcs</td>
                        <td style="text-align: center;"><?php echo $item['item_status'] == 'Issued' ? $item['quantity_requested'] : ''; ?></td>
                        <td style="text-align: center;"><?php echo $item['item_status'] == 'Issued' ? 'pcs' : ''; ?></td>
                        <td style="text-align: center;"><?php echo $item['quantity_returned'] ?: ''; ?></td>
                        <td style="text-align: center;"><?php echo $item['quantity_returned'] ? 'pcs' : ''; ?></td>
                        <td></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <!-- Add empty rows -->
                    <?php for ($i = count($request_items); $i < 15; $i++): ?>
                    <tr>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                    </tr>
                    <?php endfor; ?>
                </tbody>
            </table>

        <?php elseif ($slip_type == 'room'): ?>
            <!-- Room Reservation Slip -->
            <div class="slip-header">
                <div class="college-name">STI COLLEGE BALAGTAS</div>
                <div>Mc Arthur Hi-way, Brgy. Wawa, Balagtas, Bulacan</div>
                <div class="slip-title">Room Reservation Form</div>
            </div>

            <div class="slip-info">
                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">Instructor Name:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['instructor_name']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Subject:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['class_subject']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Room:</span>
                        <span class="info-value"><?php echo htmlspecialchars($request['room_name'] . ' (' . $request['room_type'] . ')'); ?></span>
                    </div>
                </div>
                <div class="info-section">
                    <div class="info-row">
                        <span class="info-label">Date:</span>
                        <span class="info-value"><?php echo formatDate($request['scheduled_date']); ?></span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Time:</span>
                        <span class="info-value">
                            <?php echo date('g:i A', strtotime($request['start_time'])); ?> - 
                            <?php echo date('g:i A', strtotime($request['end_time'])); ?>
                        </span>
                    </div>
                </div>
            </div>

            <?php if ($request['purpose']): ?>
            <div class="info-row" style="margin: 20px 0;">
                <span class="info-label">Purpose/Notes:</span>
                <span class="info-value"><?php echo htmlspecialchars($request['purpose']); ?></span>
            </div>
            <?php endif; ?>

            <div class="signatures">
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-label">Instructor Signature</div>
                </div>
                <div class="signature-section">
                    <div class="signature-line"></div>
                    <div class="signature-label">Approved by</div>
                </div>
            </div>

        <?php endif; ?>

        <div class="status-info no-print">
            <strong>Request Status:</strong> <?php echo $request['status']; ?><br>
            <strong>Request ID:</strong> #<?php echo str_pad($request_id, 4, '0', STR_PAD_LEFT); ?><br>
            <strong>Generated:</strong> <?php echo date('M d, Y g:i A'); ?>
            <?php if ($request['approved_by']): ?>
                <br><strong>Approved by:</strong> <?php echo htmlspecialchars($request['approver_first_name'] . ' ' . $request['approver_last_name']); ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
