<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/database.php';
require_once '../config/functions.php';

// API Response helper
function sendResponse($success, $message, $data = null, $code = 200) {
    http_response_code($code);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit();
}

// Get Authorization header
function getAuthHeader() {
    $headers = apache_request_headers();
    if (isset($headers['Authorization'])) {
        return $headers['Authorization'];
    }
    return null;
}

// Verify JWT token (simple implementation)
function verifyToken($token) {
    global $pdo;
    
    if (!$token || !str_starts_with($token, 'Bearer ')) {
        return false;
    }
    
    $token = substr($token, 7); // Remove 'Bearer ' prefix
    
    try {
        // Simple token verification - in production, use proper JWT
        $decoded = base64_decode($token);
        $data = json_decode($decoded, true);
        
        if (!$data || !isset($data['user_id']) || !isset($data['expires'])) {
            return false;
        }
        
        if (time() > $data['expires']) {
            return false; // Token expired
        }
        
        // Verify user exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ? AND archived = FALSE");
        $stmt->execute([$data['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return false;
        }
        
        return $user;
    } catch (Exception $e) {
        return false;
    }
}

// Generate simple token
function generateToken($user) {
    $data = [
        'user_id' => $user['user_id'],
        'user_type' => $user['user_type'],
        'expires' => time() + (24 * 60 * 60) // 24 hours
    ];
    
    return base64_encode(json_encode($data));
}

// Require authentication
function requireAuth() {
    $token = getAuthHeader();
    $user = verifyToken($token);
    
    if (!$user) {
        sendResponse(false, 'Unauthorized', null, 401);
    }
    
    return $user;
}
?>
