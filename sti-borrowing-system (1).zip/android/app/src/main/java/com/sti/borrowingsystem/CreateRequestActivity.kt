package com.sti.borrowingsystem

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.sti.borrowingsystem.adapters.SelectedItemsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.ActivityCreateRequestBinding
import com.sti.borrowingsystem.models.CreateRequestRequest
import com.sti.borrowingsystem.models.Item
import com.sti.borrowingsystem.models.RequestItemInput
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class CreateRequestActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateRequestBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var selectedItemsAdapter: SelectedItemsAdapter
    private val selectedItems = mutableListOf<Pair<Item, Int>>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateRequestBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        
        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        handleSelectedItems()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Create Borrowing Request"
    }

    private fun setupRecyclerView() {
        selectedItemsAdapter = SelectedItemsAdapter(
            onQuantityChanged = { item, newQuantity ->
                updateItemQuantity(item, newQuantity)
            },
            onRemoveItem = { item ->
                removeItem(item)
            }
        )
        
        binding.rvSelectedItems.apply {
            layoutManager = LinearLayoutManager(this@CreateRequestActivity)
            adapter = selectedItemsAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnSelectDate.setOnClickListener {
            showDatePicker()
        }
        
        binding.btnSelectStartTime.setOnClickListener {
            showTimePicker(true)
        }
        
        binding.btnSelectEndTime.setOnClickListener {
            showTimePicker(false)
        }
        
        binding.btnAddItems.setOnClickListener {
            val intent = Intent(this, BrowseItemsActivity::class.java)
            intent.putExtra("selection_mode", true)
            startActivityForResult(intent, REQUEST_SELECT_ITEMS)
        }
        
        binding.btnSubmitRequest.setOnClickListener {
            submitRequest()
        }
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, 1) // Minimum tomorrow
        
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, dayOfMonth)
                binding.tvSelectedDate.text = dateFormat.format(selectedDate.time)
                binding.tvSelectedDate.tag = dateFormat.format(selectedDate.time)
                validateForm()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        
        datePickerDialog.datePicker.minDate = calendar.timeInMillis
        datePickerDialog.show()
    }

    private fun showTimePicker(isStartTime: Boolean) {
        val calendar = Calendar.getInstance()
        
        val timePickerDialog = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                val time = String.format("%02d:%02d", hourOfDay, minute)
                if (isStartTime) {
                    binding.tvSelectedStartTime.text = time
                    binding.tvSelectedStartTime.tag = time
                } else {
                    binding.tvSelectedEndTime.text = time
                    binding.tvSelectedEndTime.tag = time
                }
                validateForm()
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        )
        
        timePickerDialog.show()
    }

    private fun handleSelectedItems() {
        val selectedItemIds = intent.getIntegerArrayListExtra("selected_items")
        if (selectedItemIds != null && selectedItemIds.isNotEmpty()) {
            loadSelectedItems(selectedItemIds)
        }
    }

    private fun loadSelectedItems(itemIds: List<Int>) {
        lifecycleScope.launch {
            try {
                val token = sessionManager.getAuthHeader()!!
                val response = ApiClient.itemService.getItems(token, availableOnly = true)
                
                if (response.success) {
                    val itemsToAdd = response.data.filter { item ->
                        itemIds.contains(item.item_id) && 
                        selectedItems.none { it.first.item_id == item.item_id }
                    }
                    
                    itemsToAdd.forEach { item ->
                        selectedItems.add(Pair(item, 1))
                    }
                    
                    updateUI()
                }
            } catch (e: Exception) {
                Toast.makeText(this@CreateRequestActivity, "Failed to load items", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateItemQuantity(item: Item, newQuantity: Int) {
        val index = selectedItems.indexOfFirst { it.first.item_id == item.item_id }
        if (index != -1) {
            if (newQuantity > 0) {
                selectedItems[index] = Pair(item, newQuantity)
            } else {
                selectedItems.removeAt(index)
            }
            updateUI()
        }
    }

    private fun removeItem(item: Item) {
        selectedItems.removeAll { it.first.item_id == item.item_id }
        updateUI()
    }

    private fun updateUI() {
        selectedItemsAdapter.updateItems(selectedItems)
        
        if (selectedItems.isEmpty()) {
            binding.tvEmptyItems.visibility = View.VISIBLE
            binding.rvSelectedItems.visibility = View.GONE
        } else {
            binding.tvEmptyItems.visibility = View.GONE
            binding.rvSelectedItems.visibility = View.VISIBLE
        }
        
        validateForm()
    }

    private fun validateForm() {
        val hasSubject = !binding.etSubject.text.isNullOrBlank()
        val hasDate = binding.tvSelectedDate.tag != null
        val hasStartTime = binding.tvSelectedStartTime.tag != null
        val hasEndTime = binding.tvSelectedEndTime.tag != null
        val hasItems = selectedItems.isNotEmpty()
        
        binding.btnSubmitRequest.isEnabled = hasSubject && hasDate && hasStartTime && hasEndTime && hasItems
    }

    private fun submitRequest() {
        val subject = binding.etSubject.text.toString().trim()
        val purpose = binding.etPurpose.text.toString().trim()
        val roomNumber = binding.etRoomNumber.text.toString().trim()
        val instructorName = binding.etInstructorName.text.toString().trim()
        val scheduledDate = binding.tvSelectedDate.tag as? String
        val startTime = binding.tvSelectedStartTime.tag as? String
        val endTime = binding.tvSelectedEndTime.tag as? String
        
        showLoading(true)
        
        lifecycleScope.launch {
            try {
                val token = sessionManager.getAuthHeader()!!
                
                val requestItems = selectedItems.map { (item, quantity) ->
                    RequestItemInput(item.item_id, quantity)
                }
                
                val createRequest = CreateRequestRequest(
                    subject = subject,
                    purpose = purpose.ifEmpty { null },
                    room_number = roomNumber.ifEmpty { null },
                    instructor_name = instructorName.ifEmpty { null },
                    scheduled_date = scheduledDate!!,
                    start_time = startTime!!,
                    end_time = endTime!!,
                    items = requestItems
                )
                
                val response = ApiClient.requestService.createRequest(token, createRequest)
                
                if (response.success) {
                    MaterialAlertDialogBuilder(this@CreateRequestActivity)
                        .setTitle("Request Submitted")
                        .setMessage("Your borrowing request #${response.data.formatted_id} has been submitted successfully!\n\nYou will be notified when it's reviewed.")
                        .setPositiveButton("OK") { _, _ ->
                            setResult(RESULT_OK)
                            finish()
                        }
                        .setCancelable(false)
                        .show()
                } else {
                    Toast.makeText(this@CreateRequestActivity, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@CreateRequestActivity, "Failed to submit request: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                showLoading(false)
            }
        }
    }

    private fun showLoading(show: Boolean) {
        binding.progressBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.btnSubmitRequest.isEnabled = !show && selectedItems.isNotEmpty()
        
        if (show) {
            binding.btnSubmitRequest.text = "Submitting..."
        } else {
            binding.btnSubmitRequest.text = "Submit Request"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_SELECT_ITEMS && resultCode == RESULT_OK) {
            val selectedItemIds = data?.getIntegerArrayListExtra("selected_items")
            if (selectedItemIds != null) {
                loadSelectedItems(selectedItemIds)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        private const val REQUEST_SELECT_ITEMS = 1001
    }
}
