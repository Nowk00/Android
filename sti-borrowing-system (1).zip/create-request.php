<?php
require_once 'config/functions.php';
requireUserType(['Borrower', 'Teacher']);

$user_info = getUserInfo($_SESSION['user_id']);
$user_type = getUserType();

$success_message = getSuccessMessage();
$error_message = getErrorMessage();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo->beginTransaction();
        
        $request_type = $_POST['request_type'] ?? 'general';
        $subject = sanitizeInput($_POST['subject']);
        $description = sanitizeInput($_POST['description'] ?? '');
        $scheduled_date = $_POST['scheduled_date'];
        
        // Validate required fields
        if (empty($subject) || empty($scheduled_date)) {
            throw new Exception('Subject and scheduled date are required.');
        }
        
        // Validate date is not in the past
        if (strtotime($scheduled_date) < strtotime('today')) {
            throw new Exception('Scheduled date cannot be in the past.');
        }
        
        // Create the borrowing request
        $stmt = $pdo->prepare("
            INSERT INTO borrowing_requests (
                requester_id, request_type, subject, description, scheduled_date,
                borrower_name, department, purpose, start_time, end_time,
                group_number, section_batch, day_of_week, class_subject, instructor_name
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $borrower_name = sanitizeInput($_POST['borrower_name'] ?? '');
        $department = sanitizeInput($_POST['department'] ?? '');
        $purpose = sanitizeInput($_POST['purpose'] ?? '');
        $start_time = $_POST['start_time'] ?? null;
        $end_time = $_POST['end_time'] ?? null;
        $group_number = sanitizeInput($_POST['group_number'] ?? '');
        $section_batch = sanitizeInput($_POST['section_batch'] ?? '');
        $day_of_week = sanitizeInput($_POST['day_of_week'] ?? '');
        $class_subject = sanitizeInput($_POST['class_subject'] ?? '');
        $instructor_name = sanitizeInput($_POST['instructor_name'] ?? '');
        
        $stmt->execute([
            $_SESSION['user_id'], $request_type, $subject, $description, $scheduled_date,
            $borrower_name, $department, $purpose, $start_time, $end_time,
            $group_number, $section_batch, $day_of_week, $class_subject, $instructor_name
        ]);
        
        $request_id = $pdo->lastInsertId();
        
        // Handle different request types
        if ($request_type == 'general') {
            // For general requests, create a custom item entry
            $item_description = sanitizeInput($_POST['item_description']);
            $quantity = (int)$_POST['quantity'];
            
            if (!empty($item_description) && $quantity > 0) {
                // Create a temporary item entry for general requests
                $stmt = $pdo->prepare("
                    INSERT INTO request_items (request_id, item_id, quantity_requested) 
                    VALUES (?, 0, ?)
                ");
                $stmt->execute([$request_id, $quantity]);
                
                // Store item description in the request description
                $stmt = $pdo->prepare("
                    UPDATE borrowing_requests 
                    SET description = CONCAT(description, '\nRequested Items: ', ?) 
                    WHERE request_id = ?
                ");
                $stmt->execute([$item_description, $request_id]);
            }
            
        } elseif ($request_type == 'hm_laboratory') {
            // Handle HM laboratory equipment
            $hm_items = [
                'HM001' => 'Old Fashion Glass',
                'HM002' => 'Shooter Glass', 
                'HM003' => 'Shot Glass',
                'HM004' => 'Double Jigger',
                'HM005' => 'Chopping Board (Green)',
                'HM006' => 'Shaker',
                'HM007' => 'Long Bar Spoon',
                'HM008' => 'Ice Bucket',
                'HM009' => 'Julep Strainer',
                'HM010' => 'Ice Tong',
                'HM011' => 'Paring Knife',
                'HM012' => 'Ice Scoop',
                'HM013' => 'Muddler'
            ];
            
            foreach ($hm_items as $item_code => $item_name) {
                $quantity = (int)($_POST[$item_code] ?? 0);
                if ($quantity > 0) {
                    // Get item ID
                    $stmt = $pdo->prepare("SELECT item_id FROM items WHERE item_code = ?");
                    $stmt->execute([$item_code]);
                    $item_id = $stmt->fetchColumn();
                    
                    if ($item_id) {
                        $stmt = $pdo->prepare("
                            INSERT INTO request_items (request_id, item_id, quantity_requested) 
                            VALUES (?, ?, ?)
                        ");
                        $stmt->execute([$request_id, $item_id, $quantity]);
                        
                        // Update item availability
                        updateItemAvailability($item_id);
                    }
                }
            }
            
            // Add group members
            for ($i = 1; $i <= 8; $i++) {
                $member_name = sanitizeInput($_POST["member_$i"] ?? '');
                if (!empty($member_name)) {
                    $stmt = $pdo->prepare("
                        INSERT INTO request_group_members (request_id, member_name) 
                        VALUES (?, ?)
                    ");
                    $stmt->execute([$request_id, $member_name]);
                }
            }
            
        } elseif ($request_type == 'room' && $user_type == 'Teacher') {
            // Handle room reservation
            $room_id = (int)$_POST['room_id'];
            
            if ($room_id && $start_time && $end_time) {
                // Check room availability
                if (!getRoomAvailability($room_id, $scheduled_date, $start_time, $end_time)) {
                    throw new Exception('Room is not available at the selected time.');
                }
                
                // Update request with room ID
                $stmt = $pdo->prepare("UPDATE borrowing_requests SET room_id = ? WHERE request_id = ?");
                $stmt->execute([$room_id, $request_id]);
                
                // Create room reservation
                $stmt = $pdo->prepare("
                    INSERT INTO room_reservations (room_id, request_id, reserved_date, start_time, end_time) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$room_id, $request_id, $scheduled_date, $start_time, $end_time]);
            }
        }
        
        $pdo->commit();
        
        // Log activity
        logActivity($_SESSION['user_id'], 'Create Request', "Created $request_type request #$request_id");
        
        // Notify custodians
        $stmt = $pdo->prepare("SELECT user_id FROM users WHERE user_type IN ('Custodian', 'Administrator') AND archived = FALSE");
        $stmt->execute();
        $custodians = $stmt->fetchAll();
        
        foreach ($custodians as $custodian) {
            createNotification(
                $custodian['user_id'], 
                "New $request_type request #$request_id from " . $user_info['first_name'] . " " . $user_info['last_name'],
                'Info'
            );
        }
        
        setSuccessMessage("Request #$request_id has been submitted successfully!");
        header('Location: my-requests.php');
        exit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $error_message = $e->getMessage();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error_message = 'Failed to create request. Please try again.';
        error_log("Create request error: " . $e->getMessage());
    }
}

// Get available rooms for teachers
$rooms = [];
if ($user_type == 'Teacher') {
    try {
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE status = 'Available' AND archived = FALSE ORDER BY room_name");
        $stmt->execute();
        $rooms = $stmt->fetchAll();
    } catch (PDOException $e) {
        $rooms = [];
    }
}

// Get HM items for laboratory requests
$hm_items = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM items WHERE item_code LIKE 'HM%' AND archived = FALSE ORDER BY item_code");
    $stmt->execute();
    $hm_items = $stmt->fetchAll();
} catch (PDOException $e) {
    $hm_items = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Request - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .request-tabs {
            display: flex;
            background: white;
            border-radius: 8px 8px 0 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 0;
        }
        
        .tab-button {
            flex: 1;
            padding: 15px 20px;
            background: #f8f9fa;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }
        
        .tab-button:first-child {
            border-radius: 8px 0 0 0;
        }
        
        .tab-button:last-child {
            border-radius: 0 8px 0 0;
        }
        
        .tab-button.active {
            background: white;
            border-bottom-color: #667eea;
            color: #667eea;
        }
        
        .tab-button:hover:not(.active) {
            background: #e9ecef;
        }
        
        .tab-content {
            display: none;
            background: white;
            padding: 30px;
            border-radius: 0 0 8px 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .tab-content.active {
            display: block;
        }
        
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #667eea;
        }
        
        .form-section h3 {
            margin: 0 0 20px 0;
            color: #2c3e50;
            font-size: 18px;
        }
        
        .equipment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .equipment-table th,
        .equipment-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .equipment-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #555;
        }
        
        .equipment-table input[type="number"] {
            width: 80px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }
        
        .member-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .time-inputs {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .time-inputs label {
            margin: 0 5px 0 0;
            font-weight: 500;
        }
        
        .available-qty {
            color: #28a745;
            font-weight: 500;
            font-size: 12px;
        }
        
        .unavailable {
            color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .request-tabs {
                flex-direction: column;
            }
            
            .tab-button {
                border-radius: 0 !important;
                border-bottom: 1px solid #ddd;
                border-right: none;
            }
            
            .tab-button.active {
                border-bottom: 3px solid #667eea;
                border-right: none;
            }
            
            .member-grid {
                grid-template-columns: 1fr;
            }
            
            .time-inputs {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="create-request.php" class="active">Create Request</a></li>
                <li><a href="my-requests.php">My Requests</a></li>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>Create New Request</h1>
            <p>Submit a new borrowing request for equipment, laboratory, or room reservation.</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <div class="request-tabs">
            <button type="button" class="tab-button active" onclick="showTab('general')">
                📋 General Borrower's Slip
            </button>
            <button type="button" class="tab-button" onclick="showTab('hm_laboratory')">
                🧪 HM Laboratory Request
            </button>
            <?php if ($user_type == 'Teacher'): ?>
            <button type="button" class="tab-button" onclick="showTab('room')">
                🏫 Room Reservation
            </button>
            <?php endif; ?>
        </div>

        <!-- General Borrower's Slip -->
        <div id="general" class="tab-content active">
            <form method="POST" action="" id="generalForm">
                <input type="hidden" name="request_type" value="general">
                
                <div class="form-section">
                    <h3>📋 Borrower Information</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="borrower_name">Borrower Name *</label>
                                <input type="text" id="borrower_name" name="borrower_name" required 
                                       value="<?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?>">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="department">Department</label>
                                <input type="text" id="department" name="department" 
                                       placeholder="e.g., Computer Science, Business Administration">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="purpose">Purpose *</label>
                        <textarea id="purpose" name="purpose" rows="3" required 
                                  placeholder="Please describe the purpose of borrowing..."></textarea>
                    </div>
                </div>

                <div class="form-section">
                    <h3>📅 Request Details</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="general_subject">Subject/Title *</label>
                                <input type="text" id="general_subject" name="subject" required 
                                       placeholder="Brief title for your request">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="general_date">Date Needed *</label>
                                <input type="date" id="general_date" name="scheduled_date" required 
                                       min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>📦 Item Description</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="item_description">Equipment/Items Needed *</label>
                                <textarea id="item_description" name="item_description" rows="4" required 
                                          placeholder="Describe the equipment or items you need to borrow..."></textarea>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="general_quantity">Quantity</label>
                                <input type="number" id="general_quantity" name="quantity" min="1" value="1">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="general_description">Additional Notes</label>
                        <textarea id="general_description" name="description" rows="3" 
                                  placeholder="Any additional information or special requirements..."></textarea>
                    </div>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <!-- HM Laboratory Request -->
        <div id="hm_laboratory" class="tab-content">
            <form method="POST" action="" id="hmForm">
                <input type="hidden" name="request_type" value="hm_laboratory">
                
                <div class="form-section">
                    <h3>👥 Group Information</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="group_number">Group Number *</label>
                                <input type="text" id="group_number" name="group_number" required 
                                       placeholder="e.g., Group 1, Team A">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="section_batch">Section/Batch *</label>
                                <input type="text" id="section_batch" name="section_batch" required 
                                       placeholder="e.g., BSHM 3A, Section 1">
                            </div>
                        </div>
                    </div>
                    
                    <h4>Group Members (8 members maximum)</h4>
                    <div class="member-grid">
                        <?php for ($i = 1; $i <= 8; $i++): ?>
                        <div class="form-group">
                            <label for="member_<?php echo $i; ?>">Member <?php echo $i; ?> <?php echo $i <= 3 ? '*' : ''; ?></label>
                            <input type="text" id="member_<?php echo $i; ?>" name="member_<?php echo $i; ?>" 
                                   <?php echo $i <= 3 ? 'required' : ''; ?>
                                   placeholder="Full Name">
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="form-section">
                    <h3>📚 Class Details</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="hm_subject">Subject *</label>
                                <input type="text" id="hm_subject" name="subject" required 
                                       placeholder="e.g., Food and Beverage Service">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="hm_date">Date *</label>
                                <input type="date" id="hm_date" name="scheduled_date" required 
                                       min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="day_of_week">Day of Week *</label>
                                <select id="day_of_week" name="day_of_week" required>
                                    <option value="">Select Day</option>
                                    <option value="Monday">Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                    <option value="Saturday">Saturday</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="time-inputs">
                                <label for="hm_start_time">Time:</label>
                                <input type="time" id="hm_start_time" name="start_time" required>
                                <span>to</span>
                                <input type="time" id="hm_end_time" name="end_time" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>🧪 HM Laboratory Equipment</h3>
                    <p>Select the quantity needed for each equipment item:</p>
                    
                    <table class="equipment-table">
                        <thead>
                            <tr>
                                <th>Item Code</th>
                                <th>Equipment Name</th>
                                <th>Available</th>
                                <th>Quantity Needed</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($hm_items as $item): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($item['item_code']); ?></strong></td>
                                <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                <td>
                                    <span class="available-qty <?php echo $item['available_quantity'] > 0 ? '' : 'unavailable'; ?>">
                                        <?php echo $item['available_quantity']; ?> available
                                    </span>
                                </td>
                                <td>
                                    <input type="number" name="<?php echo $item['item_code']; ?>" 
                                           min="0" max="<?php echo $item['available_quantity']; ?>" 
                                           value="0" class="quantity-input">
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="form-group">
                    <label for="hm_description">Additional Notes</label>
                    <textarea id="hm_description" name="description" rows="3" 
                              placeholder="Any special instructions or requirements..."></textarea>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Submit HM Laboratory Request</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <!-- Room Reservation (Teachers only) -->
        <?php if ($user_type == 'Teacher'): ?>
        <div id="room" class="tab-content">
            <form method="POST" action="" id="roomForm">
                <input type="hidden" name="request_type" value="room">
                
                <div class="form-section">
                    <h3>📚 Class Information</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="class_subject">Subject *</label>
                                <input type="text" id="class_subject" name="subject" required 
                                       placeholder="e.g., Mathematics, Computer Programming">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="instructor_name">Instructor Name *</label>
                                <input type="text" id="instructor_name" name="instructor_name" required 
                                       value="<?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>📅 Schedule Details</h3>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="room_date">Date *</label>
                                <input type="date" id="room_date" name="scheduled_date" required 
                                       min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="time-inputs">
                                <label for="room_start_time">Time:</label>
                                <input type="time" id="room_start_time" name="start_time" required>
                                <span>to</span>
                                <input type="time" id="room_end_time" name="end_time" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-section">
                    <h3>🏫 Room Selection</h3>
                    <div class="form-group">
                        <label for="room_id">Select Room *</label>
                        <select id="room_id" name="room_id" required>
                            <option value="">Choose a room...</option>
                            <?php foreach ($rooms as $room): ?>
                            <option value="<?php echo $room['room_id']; ?>">
                                <?php echo htmlspecialchars($room['room_name']); ?> 
                                (<?php echo htmlspecialchars($room['room_type']); ?>, 
                                Capacity: <?php echo $room['capacity']; ?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="room_purpose">Purpose</label>
                        <textarea id="room_purpose" name="description" rows="3" 
                                  placeholder="Describe the purpose of the room reservation..."></textarea>
                    </div>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Reserve Room</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
        <?php endif; ?>
    </main>

    <script>
        function showTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            
            // Remove active class from all tab buttons
            document.querySelectorAll('.tab-button').forEach(button => {
                button.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
        }

        // Form validation
        document.getElementById('generalForm').addEventListener('submit', function(e) {
            const itemDescription = document.getElementById('item_description').value.trim();
            if (!itemDescription) {
                e.preventDefault();
                alert('Please describe the equipment or items you need to borrow.');
                return false;
            }
        });

        document.getElementById('hmForm').addEventListener('submit', function(e) {
            // Check if at least one equipment item is selected
            const quantityInputs = document.querySelectorAll('#hm_laboratory .quantity-input');
            let hasItems = false;
            
            quantityInputs.forEach(input => {
                if (parseInt(input.value) > 0) {
                    hasItems = true;
                }
            });
            
            if (!hasItems) {
                e.preventDefault();
                alert('Please select at least one equipment item for the laboratory request.');
                return false;
            }
            
            // Validate time
            const startTime = document.getElementById('hm_start_time').value;
            const endTime = document.getElementById('hm_end_time').value;
            
            if (startTime && endTime && startTime >= endTime) {
                e.preventDefault();
                alert('End time must be after start time.');
                return false;
            }
        });

        <?php if ($user_type == 'Teacher'): ?>
        document.getElementById('roomForm').addEventListener('submit', function(e) {
            const startTime = document.getElementById('room_start_time').value;
            const endTime = document.getElementById('room_end_time').value;
            
            if (startTime && endTime && startTime >= endTime) {
                e.preventDefault();
                alert('End time must be after start time.');
                return false;
            }
        });
        <?php endif; ?>

        // Auto-update day of week when date is selected
        document.getElementById('hm_date').addEventListener('change', function() {
            const date = new Date(this.value);
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const dayName = days[date.getDay()];
            document.getElementById('day_of_week').value = dayName;
        });

        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.querySelectorAll('input[type="date"]').forEach(input => {
            input.min = today;
        });
    </script>
</body>
</html>
