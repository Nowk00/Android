<?php
require_once 'config/functions.php';
requireUserType(['Custodian', 'Administrator']);

$user_info = getUserInfo($_SESSION['user_id']);
$user_type = getUserType();

$success_message = '';
$error_message = '';

// Handle item actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'add_item':
                $item_code = sanitizeInput($_POST['item_code']);
                $item_name = sanitizeInput($_POST['item_name']);
                $description = sanitizeInput($_POST['description']);
                $quantity = (int)$_POST['quantity'];
                $condition_status = $_POST['condition_status'];
                $location = sanitizeInput($_POST['location'] ?? '');
                
                if (empty($item_code) || empty($item_name) || $quantity < 0) {
                    $error_message = 'Please fill in all required fields with valid values.';
                } elseif (itemCodeExists($item_code)) {
                    $error_message = 'Item code already exists. Please use a different code.';
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO items (item_code, item_name, description, quantity, available_quantity, condition_status, location, added_by) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$item_code, $item_name, $description, $quantity, $quantity, $condition_status, $location, $_SESSION['user_id']]);
                    
                    logActivity($_SESSION['user_id'], 'Add Item', "Added new item: $item_name ($item_code)");
                    $success_message = "Item '$item_name' has been added successfully!";
                }
                break;
                
            case 'edit_item':
                $item_id = (int)$_POST['item_id'];
                $item_name = sanitizeInput($_POST['item_name']);
                $description = sanitizeInput($_POST['description']);
                $quantity = (int)$_POST['quantity'];
                $condition_status = $_POST['condition_status'];
                $location = sanitizeInput($_POST['location'] ?? '');
                
                if (empty($item_name) || $quantity < 0) {
                    $error_message = 'Please fill in all required fields with valid values.';
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE items 
                        SET item_name = ?, description = ?, quantity = ?, condition_status = ?, location = ?
                        WHERE item_id = ?
                    ");
                    $stmt->execute([$item_name, $description, $quantity, $condition_status, $location, $item_id]);
                    
                    // Update available quantity
                    updateItemAvailability($item_id);
                    
                    logActivity($_SESSION['user_id'], 'Edit Item', "Updated item: $item_name (ID: $item_id)");
                    $success_message = "Item has been updated successfully!";
                }
                break;
                
            case 'update_condition':
                $item_id = (int)$_POST['item_id'];
                $condition_status = $_POST['condition_status'];
                $maintenance_notes = sanitizeInput($_POST['maintenance_notes'] ?? '');
                
                $stmt = $pdo->prepare("
                    UPDATE items 
                    SET condition_status = ?, maintenance_notes = ?, last_maintenance = NOW()
                    WHERE item_id = ?
                ");
                $stmt->execute([$condition_status, $maintenance_notes, $item_id]);
                
                // Update availability based on condition
                if (in_array($condition_status, ['Under Repair', 'Damaged', 'Not Available'])) {
                    $stmt = $pdo->prepare("UPDATE items SET available_quantity = 0 WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                } else {
                    updateItemAvailability($item_id);
                }
                
                logActivity($_SESSION['user_id'], 'Update Item Condition', "Updated condition for item ID: $item_id to $condition_status");
                $success_message = "Item condition has been updated successfully!";
                break;
                
            case 'delete_item':
                $item_id = (int)$_POST['item_id'];
                
                // Check if item is currently borrowed
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM request_items ri
                    JOIN borrowing_requests br ON ri.request_id = br.request_id
                    WHERE ri.item_id = ? AND ri.item_status IN ('Pending', 'Issued')
                ");
                $stmt->execute([$item_id]);
                $active_borrows = $stmt->fetchColumn();
                
                if ($active_borrows > 0) {
                    $error_message = 'Cannot delete item. It is currently borrowed or has pending requests.';
                } else {
                    $stmt = $pdo->prepare("UPDATE items SET archived = TRUE WHERE item_id = ?");
                    $stmt->execute([$item_id]);
                    
                    logActivity($_SESSION['user_id'], 'Delete Item', "Archived item (ID: $item_id)");
                    $success_message = "Item has been archived successfully!";
                }
                break;
        }
    } catch(PDOException $e) {
        $error_message = 'Operation failed. Please try again.';
        error_log("Manage items error: " . $e->getMessage());
    }
}

// Get items with filters
$search = $_GET['search'] ?? '';
$condition_filter = $_GET['condition'] ?? 'all';
$location_filter = $_GET['location'] ?? 'all';

$where_conditions = ["archived = FALSE"];
$params = [];

if (!empty($search)) {
    $where_conditions[] = "(item_name LIKE ? OR item_code LIKE ? OR description LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param]);
}

if ($condition_filter !== 'all') {
    $where_conditions[] = "condition_status = ?";
    $params[] = $condition_filter;
}

if ($location_filter !== 'all') {
    $where_conditions[] = "location = ?";
    $params[] = $location_filter;
}

$where_clause = implode(' AND ', $where_conditions);

try {
    $stmt = $pdo->prepare("
        SELECT i.*, u.first_name, u.last_name,
               COALESCE(SUM(CASE WHEN ri.item_status IN ('Pending', 'Issued') THEN ri.quantity_requested ELSE 0 END), 0) as borrowed_qty
        FROM items i
        LEFT JOIN users u ON i.added_by = u.user_id
        LEFT JOIN request_items ri ON i.item_id = ri.item_id
        WHERE $where_clause
        GROUP BY i.item_id
        ORDER BY i.created_at DESC
    ");
    $stmt->execute($params);
    $items = $stmt->fetchAll();
    
    // Get unique locations for filter
    $stmt = $pdo->prepare("SELECT DISTINCT location FROM items WHERE archived = FALSE AND location IS NOT NULL AND location != '' ORDER BY location");
    $stmt->execute();
    $locations = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
} catch(PDOException $e) {
    $items = [];
    $locations = [];
    $error_message = 'Failed to load items.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Items - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .condition-update-form {
            display: inline-block;
            margin-left: 10px;
        }
        
        .condition-select {
            padding: 4px 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 12px;
        }
        
        .update-btn {
            padding: 4px 8px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-left: 5px;
        }
        
        .maintenance-notes {
            font-size: 11px;
            color: #666;
            font-style: italic;
            margin-top: 2px;
        }
        
        .item-location {
            background: #e3f2fd;
            color: #1976d2;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 11px;
            display: inline-block;
            margin-top: 2px;
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="manage-requests.php">Manage Requests</a></li>
                <li><a href="manage-items.php" class="active">Manage Items</a></li>
                <?php if ($user_type == 'Administrator'): ?>
                    <li><a href="manage-users.php">Manage Users</a></li>
                    <li><a href="reports.php">Reports</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>Manage Items</h1>
            <p>Add, edit, and manage all borrowable items in the system.</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Add New Item -->
        <div class="card">
            <div class="card-header">
                <h3>Add New Item</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="add_item">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="item_code">Item Code *</label>
                                <input type="text" id="item_code" name="item_code" required 
                                       placeholder="e.g., PROJ001" value="<?php echo generateItemCode(); ?>">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="item_name">Item Name *</label>
                                <input type="text" id="item_name" name="item_name" required 
                                       placeholder="e.g., LCD Projector">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="quantity">Quantity *</label>
                                <input type="number" id="quantity" name="quantity" required min="0" value="1">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="condition_status">Condition *</label>
                                <select id="condition_status" name="condition_status" required>
                                    <option value="Good">Good</option>
                                    <option value="Fair">Fair</option>
                                    <option value="Damaged">Damaged</option>
                                    <option value="Under Repair">Under Repair</option>
                                    <option value="Not Available">Not Available</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="location">Location</label>
                                <input type="text" id="location" name="location" 
                                       placeholder="e.g., Room 101, Storage A">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea id="description" name="description" rows="2" 
                                          placeholder="Detailed description of the item..."></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Item</button>
                </form>
            </div>
        </div>

        <!-- Search and Filter -->
        <div class="card">
            <div class="card-header">
                <h3>Search & Filter Items</h3>
            </div>
            <div class="card-body">
                <form method="GET" action="" class="filter-form">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="search">Search:</label>
                                <input type="text" id="search" name="search" 
                                       placeholder="Search by name, code, or description..."
                                       value="<?php echo htmlspecialchars($search); ?>">
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="condition">Condition:</label>
                                <select id="condition" name="condition">
                                    <option value="all" <?php echo $condition_filter == 'all' ? 'selected' : ''; ?>>All Conditions</option>
                                    <option value="Good" <?php echo $condition_filter == 'Good' ? 'selected' : ''; ?>>Good</option>
                                    <option value="Fair" <?php echo $condition_filter == 'Fair' ? 'selected' : ''; ?>>Fair</option>
                                    <option value="Damaged" <?php echo $condition_filter == 'Damaged' ? 'selected' : ''; ?>>Damaged</option>
                                    <option value="Under Repair" <?php echo $condition_filter == 'Under Repair' ? 'selected' : ''; ?>>Under Repair</option>
                                    <option value="Not Available" <?php echo $condition_filter == 'Not Available' ? 'selected' : ''; ?>>Not Available</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="location">Location:</label>
                                <select id="location" name="location">
                                    <option value="all" <?php echo $location_filter == 'all' ? 'selected' : ''; ?>>All Locations</option>
                                    <?php foreach ($locations as $location): ?>
                                        <option value="<?php echo htmlspecialchars($location); ?>" 
                                                <?php echo $location_filter == $location ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($location); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Items Table -->
        <div class="card">
            <div class="card-header">
                <h3>Items Inventory (<?php echo count($items); ?> items)</h3>
            </div>
            <div class="card-body">
                <?php if (empty($items)): ?>
                    <p>No items found matching your criteria.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Name</th>
                                    <th>Description</th>
                                    <th>Quantity</th>
                                    <th>Available</th>
                                    <th>Condition</th>
                                    <th>Location</th>
                                    <th>Added By</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['item_code']); ?></strong></td>
                                    <td>
                                        <?php echo htmlspecialchars($item['item_name']); ?>
                                        <?php if ($item['location']): ?>
                                            <br><span class="item-location"><?php echo htmlspecialchars($item['location']); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <small><?php echo htmlspecialchars($item['description'] ?: 'No description'); ?></small>
                                        <?php if ($item['maintenance_notes']): ?>
                                            <div class="maintenance-notes">
                                                Notes: <?php echo htmlspecialchars($item['maintenance_notes']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>
                                        <span class="<?php echo $item['available_quantity'] > 0 ? 'text-success' : 'text-danger'; ?>">
                                            <?php echo $item['available_quantity']; ?>
                                        </span>
                                        <?php if ($item['borrowed_qty'] > 0): ?>
                                            <br><small class="text-muted">(<?php echo $item['borrowed_qty']; ?> borrowed)</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $item['condition_status'])); ?>">
                                            <?php echo $item['condition_status']; ?>
                                        </span>
                                        
                                        <!-- Quick condition update for custodians -->
                                        <form method="POST" class="condition-update-form">
                                            <input type="hidden" name="action" value="update_condition">
                                            <input type="hidden" name="item_id" value="<?php echo $item['item_id']; ?>">
                                            <select name="condition_status" class="condition-select" onchange="this.form.submit()">
                                                <option value="Good" <?php echo $item['condition_status'] == 'Good' ? 'selected' : ''; ?>>Good</option>
                                                <option value="Fair" <?php echo $item['condition_status'] == 'Fair' ? 'selected' : ''; ?>>Fair</option>
                                                <option value="Damaged" <?php echo $item['condition_status'] == 'Damaged' ? 'selected' : ''; ?>>Damaged</option>
                                                <option value="Under Repair" <?php echo $item['condition_status'] == 'Under Repair' ? 'selected' : ''; ?>>Under Repair</option>
                                                <option value="Not Available" <?php echo $item['condition_status'] == 'Not Available' ? 'selected' : ''; ?>>Not Available</option>
                                            </select>
                                        </form>
                                    </td>
                                    <td><?php echo htmlspecialchars($item['location'] ?: 'Not specified'); ?></td>
                                    <td>
                                        <small><?php echo htmlspecialchars(($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? '')); ?></small>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="btn btn-warning btn-sm" onclick="editItem(<?php echo htmlspecialchars(json_encode($item)); ?>)">Edit</button>
                                            <button class="btn btn-info btn-sm" onclick="showMaintenanceModal(<?php echo $item['item_id']; ?>, '<?php echo htmlspecialchars($item['item_name']); ?>')">Maintenance</button>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="delete_item">
                                                <input type="hidden" name="item_id" value="<?php echo $item['item_id']; ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" 
                                                        onclick="return confirm('Are you sure you want to archive this item?')">Archive</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Edit Item Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Item</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form method="POST" id="editForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit_item">
                    <input type="hidden" name="item_id" id="editItemId">
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editItemName">Item Name *</label>
                                <input type="text" id="editItemName" name="item_name" required>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editQuantity">Quantity *</label>
                                <input type="number" id="editQuantity" name="quantity" required min="0">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editCondition">Condition *</label>
                                <select id="editCondition" name="condition_status" required>
                                    <option value="Good">Good</option>
                                    <option value="Fair">Fair</option>
                                    <option value="Damaged">Damaged</option>
                                    <option value="Under Repair">Under Repair</option>
                                    <option value="Not Available">Not Available</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="editLocation">Location</label>
                                <input type="text" id="editLocation" name="location">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="editDescription">Description</label>
                        <textarea id="editDescription" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Item</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Maintenance Modal -->
    <div id="maintenanceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Item Maintenance</h3>
                <span class="close" onclick="closeMaintenanceModal()">&times;</span>
            </div>
            <form method="POST" id="maintenanceForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_condition">
                    <input type="hidden" name="item_id" id="maintenanceItemId">
                    
                    <p>Update maintenance status for: <strong id="maintenanceItemName"></strong></p>
                    
                    <div class="form-group">
                        <label for="maintenanceCondition">Condition Status *</label>
                        <select id="maintenanceCondition" name="condition_status" required>
                            <option value="Good">Good</option>
                            <option value="Fair">Fair</option>
                            <option value="Damaged">Damaged</option>
                            <option value="Under Repair">Under Repair</option>
                            <option value="Not Available">Not Available</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="maintenanceNotes">Maintenance Notes</label>
                        <textarea id="maintenanceNotes" name="maintenance_notes" rows="4" 
                                  placeholder="Enter maintenance notes, repair details, or reason for status change..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeMaintenanceModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Status</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function editItem(item) {
            document.getElementById('editItemId').value = item.item_id;
            document.getElementById('editItemName').value = item.item_name;
            document.getElementById('editQuantity').value = item.quantity;
            document.getElementById('editCondition').value = item.condition_status;
            document.getElementById('editLocation').value = item.location || '';
            document.getElementById('editDescription').value = item.description || '';
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function showMaintenanceModal(itemId, itemName) {
            document.getElementById('maintenanceItemId').value = itemId;
            document.getElementById('maintenanceItemName').textContent = itemName;
            document.getElementById('maintenanceNotes').value = '';
            document.getElementById('maintenanceModal').style.display = 'block';
        }

        function closeMaintenanceModal() {
            document.getElementById('maintenanceModal').style.display = 'none';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const editModal = document.getElementById('editModal');
            const maintenanceModal = document.getElementById('maintenanceModal');
            
            if (event.target == editModal) {
                closeEditModal();
            }
            if (event.target == maintenanceModal) {
                closeMaintenanceModal();
            }
        }

        // Generate random item code
        document.getElementById('item_code').addEventListener('focus', function() {
            if (this.value === '<?php echo generateItemCode(); ?>') {
                this.value = '<?php echo generateItemCode(); ?>';
            }
        });
    </script>
</body>
</html>
