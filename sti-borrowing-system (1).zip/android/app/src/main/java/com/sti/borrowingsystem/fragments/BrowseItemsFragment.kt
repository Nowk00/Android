package com.sti.borrowingsystem.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.chip.Chip
import com.sti.borrowingsystem.ItemDetailActivity
import com.sti.borrowingsystem.adapters.ItemsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.FragmentBrowseItemsBinding
import com.sti.borrowingsystem.models.Item
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class BrowseItemsFragment : Fragment() {
    
    private var _binding: FragmentBrowseItemsBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var sessionManager: SessionManager
    private lateinit var itemsAdapter: ItemsAdapter
    private var allItems = listOf<Item>()
    private var filteredItems = listOf<Item>()
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBrowseItemsBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        sessionManager = SessionManager(requireContext())
        setupRecyclerView()
        setupSearch()
        setupFilters()
        setupSwipeRefresh()
        loadItems()
    }
    
    private fun setupRecyclerView() {
        itemsAdapter = ItemsAdapter(
            isSelectionMode = false,
            onItemClick = { item ->
                showItemDetail(item)
            }
        )
        
        binding.rvItems.apply {
            layoutManager = GridLayoutManager(context, 2)
            adapter = itemsAdapter
        }
    }
    
    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                filterItems()
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterItems()
                return true
            }
        })
    }
    
    private fun setupFilters() {
        // Category filters
        val categories = listOf("All", "Electronics", "Laboratory", "Sports", "Furniture", "Tools")
        categories.forEach { category ->
            val chip = Chip(context)
            chip.text = category
            chip.isCheckable = true
            chip.isChecked = category == "All"
            chip.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    // Uncheck other chips
                    for (i in 0 until binding.chipGroupCategories.childCount) {
                        val otherChip = binding.chipGroupCategories.getChildAt(i) as Chip
                        if (otherChip != chip) {
                            otherChip.isChecked = false
                        }
                    }
                    filterItems()
                }
            }
            binding.chipGroupCategories.addView(chip)
        }

        // Available only switch
        binding.switchAvailableOnly.setOnCheckedChangeListener { _, _ ->
            filterItems()
        }
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadItems()
        }
    }
    
    fun refreshData() {
        loadItems()
    }
    
    private fun loadItems() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(context, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val response = ApiClient.itemService.getItems(
                    token = token,
                    availableOnly = binding.switchAvailableOnly.isChecked
                )

                if (response.success) {
                    allItems = response.data
                    filterItems()
                } else {
                    Toast.makeText(context, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load items: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun filterItems() {
        val query = binding.searchView.query.toString().lowercase()
        val selectedCategory = getSelectedChip(binding.chipGroupCategories)
        val availableOnly = binding.switchAvailableOnly.isChecked

        filteredItems = allItems.filter { item ->
            val matchesQuery = query.isEmpty() || 
                item.item_name.lowercase().contains(query) ||
                item.description?.lowercase()?.contains(query) == true

            val matchesCategory = selectedCategory == "All" || 
                item.category_name?.equals(selectedCategory, ignoreCase = true) == true

            val matchesAvailability = !availableOnly || item.quantity_available > 0

            matchesQuery && matchesCategory && matchesAvailability
        }

        itemsAdapter.updateItems(filteredItems)
        updateEmptyState()
    }
    
    private fun getSelectedChip(chipGroup: com.google.android.material.chip.ChipGroup): String {
        for (i in 0 until chipGroup.childCount) {
            val chip = chipGroup.getChildAt(i) as Chip
            if (chip.isChecked) {
                return chip.text.toString()
            }
        }
        return "All"
    }
    
    private fun updateEmptyState() {
        if (filteredItems.isEmpty()) {
            binding.tvEmptyItems.visibility = View.VISIBLE
            binding.rvItems.visibility = View.GONE
            
            binding.tvEmptyItems.text = if (allItems.isEmpty()) {
                "No items available"
            } else {
                "No items match your filters"
            }
        } else {
            binding.tvEmptyItems.visibility = View.GONE
            binding.rvItems.visibility = View.VISIBLE
        }
    }
    
    private fun showItemDetail(item: Item) {
        val intent = Intent(context, ItemDetailActivity::class.java)
        intent.putExtra("item_id", item.item_id)
        startActivity(intent)
    }
    
    override fun onResume() {
        super.onResume()
        loadItems()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
