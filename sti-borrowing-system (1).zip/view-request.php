<?php
require_once 'config/functions.php';
requireLogin();

$user_info = getUserInfo($_SESSION['user_id']);
$user_type = getUserType();

$request_id = $_GET['id'] ?? 0;
$success_message = '';
$error_message = '';

// Get request details
try {
    $stmt = $pdo->prepare("
        SELECT br.*, 
               requester.first_name as requester_first_name, 
               requester.last_name as requester_last_name,
               requester.id_number as requester_id_number,
               requester.email as requester_email,
               approver.first_name as approver_first_name, 
               approver.last_name as approver_last_name
        FROM borrowing_requests br
        JOIN users requester ON br.requester_id = requester.user_id
        LEFT JOIN users approver ON br.approved_by = approver.user_id
        WHERE br.request_id = ? AND br.archived = FALSE
    ");
    $stmt->execute([$request_id]);
    $request = $stmt->fetch();
    
    if (!$request) {
        header("Location: dashboard.php");
        exit();
    }
    
    // Check permissions
    if ($user_type == 'Borrower' && $request['requester_id'] != $_SESSION['user_id']) {
        header("Location: dashboard.php");
        exit();
    }
    
    // Get request items
    $stmt = $pdo->prepare("
        SELECT ri.*, i.item_name, i.item_code, i.description
        FROM request_items ri
        JOIN items i ON ri.item_id = i.item_id
        WHERE ri.request_id = ?
        ORDER BY i.item_name
    ");
    $stmt->execute([$request_id]);
    $request_items = $stmt->fetchAll();
    
} catch(PDOException $e) {
    header("Location: dashboard.php");
    exit();
}

// Handle quick actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && in_array($user_type, ['Custodian', 'Administrator'])) {
    $action = $_POST['action'] ?? '';
    
    try {
        switch ($action) {
            case 'approve':
                $stmt = $pdo->prepare("
                    UPDATE borrowing_requests 
                    SET status = 'Approved', approved_by = ? 
                    WHERE request_id = ? AND status = 'Pending'
                ");
                $stmt->execute([$_SESSION['user_id'], $request_id]);
                
                // Update request items status
                $stmt = $pdo->prepare("
                    UPDATE request_items 
                    SET item_status = 'Issued', issued_date = NOW() 
                    WHERE request_id = ?
                ");
                $stmt->execute([$request_id]);
                
                // Update item availability
                foreach ($request_items as $item) {
                    updateItemAvailability($item['item_id']);
                }
                
                createNotification($request['requester_id'], "Your borrowing request #$request_id has been approved!", 'Success');
                logActivity($_SESSION['user_id'], 'Approve Request', "Approved borrowing request #$request_id");
                
                $success_message = "Request has been approved successfully!";
                $request['status'] = 'Approved';
                break;
                
            case 'reject':
                $reason = sanitizeInput($_POST['reason'] ?? 'No reason provided');
                $stmt = $pdo->prepare("
                    UPDATE borrowing_requests 
                    SET status = 'Rejected', approved_by = ? 
                    WHERE request_id = ? AND status = 'Pending'
                ");
                $stmt->execute([$_SESSION['user_id'], $request_id]);
                
                // Update request items status
                $stmt = $pdo->prepare("
                    UPDATE request_items 
                    SET item_status = 'Rejected' 
                    WHERE request_id = ?
                ");
                $stmt->execute([$request_id]);
                
                // Update item availability
                foreach ($request_items as $item) {
                    updateItemAvailability($item['item_id']);
                }
                
                createNotification($request['requester_id'], "Your borrowing request #$request_id has been rejected. Reason: $reason", 'Warning');
                logActivity($_SESSION['user_id'], 'Reject Request', "Rejected borrowing request #$request_id - Reason: $reason");
                
                $success_message = "Request has been rejected.";
                $request['status'] = 'Rejected';
                break;
                
            case 'complete':
                $stmt = $pdo->prepare("
                    UPDATE borrowing_requests 
                    SET status = 'Completed' 
                    WHERE request_id = ? AND status = 'Approved'
                ");
                $stmt->execute([$request_id]);
                
                logActivity($_SESSION['user_id'], 'Complete Request', "Marked borrowing request #$request_id as completed");
                $success_message = "Request has been marked as completed.";
                $request['status'] = 'Completed';
                break;
                
            case 'return':
                $stmt = $pdo->prepare("
                    UPDATE borrowing_requests 
                    SET status = 'Returned', return_date = NOW() 
                    WHERE request_id = ? AND status IN ('Approved', 'Completed')
                ");
                $stmt->execute([$request_id]);
                
                // Update request items
                $stmt = $pdo->prepare("
                    UPDATE request_items 
                    SET item_status = 'Returned', returned_date = NOW(), quantity_returned = quantity_requested 
                    WHERE request_id = ?
                ");
                $stmt->execute([$request_id]);
                
                // Update item availability
                foreach ($request_items as $item) {
                    updateItemAvailability($item['item_id']);
                }
                
                logActivity($_SESSION['user_id'], 'Return Items', "Processed return for borrowing request #$request_id");
                $success_message = "Items have been returned successfully.";
                $request['status'] = 'Returned';
                break;
        }
    } catch(PDOException $e) {
        $error_message = 'Failed to process request. Please try again.';
        error_log("View request action error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Request #<?php echo str_pad($request_id, 4, '0', STR_PAD_LEFT); ?> - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <style>
        .request-header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .request-info {
            flex: 1;
        }
        
        .request-actions {
            display: flex;
            gap: 10px;
        }
        
        .request-details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .detail-item {
            margin-bottom: 15px;
        }
        
        .detail-label {
            font-weight: 600;
            color: #555;
            margin-bottom: 5px;
        }
        
        .detail-value {
            color: #333;
        }
        
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #ddd;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        
        .timeline-item::before {
            content: '';
            position: absolute;
            left: -25px;
            top: 5px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #667eea;
        }
        
        .timeline-date {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .timeline-content {
            background: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
        }
        
        @media (max-width: 768px) {
            .request-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .request-details-grid {
                grid-template-columns: 1fr;
            }
            
            .request-actions {
                flex-direction: column;
                width: 100%;
            }
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php">Dashboard</a></li>
                <?php if ($user_type == 'Borrower'): ?>
                    <li><a href="create-request.php">Create Request</a></li>
                    <li><a href="my-requests.php">My Requests</a></li>
                <?php endif; ?>
                <?php if (in_array($user_type, ['Custodian', 'Administrator'])): ?>
                    <li><a href="manage-requests.php">Manage Requests</a></li>
                    <li><a href="manage-items.php">Manage Items</a></li>
                <?php endif; ?>
                <?php if ($user_type == 'Administrator'): ?>
                    <li><a href="manage-users.php">Manage Users</a></li>
                    <li><a href="reports.php">Reports</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <!-- Request Header -->
        <div class="request-header">
            <div class="request-info">
                <h1>Request #<?php echo str_pad($request_id, 4, '0', STR_PAD_LEFT); ?></h1>
                <p><?php echo htmlspecialchars($request['subject']); ?></p>
                <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                    <?php echo $request['status']; ?>
                </span>
            </div>
            <div class="request-actions">
                <?php if (in_array($user_type, ['Custodian', 'Administrator'])): ?>
                    <?php if ($request['status'] == 'Pending'): ?>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="approve">
                            <button type="submit" class="btn btn-success" onclick="return confirm('Approve this request?')">Approve</button>
                        </form>
                        <button class="btn btn-danger" onclick="showRejectModal()">Reject</button>
                    <?php elseif ($request['status'] == 'Approved'): ?>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="complete">
                            <button type="submit" class="btn btn-warning" onclick="return confirm('Mark as completed?')">Complete</button>
                        </form>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="return">
                            <button type="submit" class="btn btn-secondary" onclick="return confirm('Process return?')">Return</button>
                        </form>
                    <?php elseif ($request['status'] == 'Completed'): ?>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="return">
                            <button type="submit" class="btn btn-secondary" onclick="return confirm('Process return?')">Return</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
                <button onclick="window.print()" class="btn btn-info">Print</button>
            </div>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Request Details -->
        <div class="request-details-grid">
            <div class="card">
                <div class="card-header">
                    <h3>Request Information</h3>
                </div>
                <div class="card-body">
                    <div class="detail-item">
                        <div class="detail-label">Request ID</div>
                        <div class="detail-value">#<?php echo str_pad($request_id, 4, '0', STR_PAD_LEFT); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Subject</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['subject']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Description</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['description'] ?: 'No description provided'); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Scheduled Date</div>
                        <div class="detail-value"><?php echo formatDate($request['scheduled_date']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Status</div>
                        <div class="detail-value">
                            <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                                <?php echo $request['status']; ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3>Requester Information</h3>
                </div>
                <div class="card-body">
                    <div class="detail-item">
                        <div class="detail-label">Name</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['requester_first_name'] . ' ' . $request['requester_last_name']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">ID Number</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['requester_id_number']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Email</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['requester_email']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Request Date</div>
                        <div class="detail-value"><?php echo formatDateTime($request['created_at']); ?></div>
                    </div>
                    <?php if ($request['approved_by']): ?>
                    <div class="detail-item">
                        <div class="detail-label">Approved By</div>
                        <div class="detail-value"><?php echo htmlspecialchars($request['approver_first_name'] . ' ' . $request['approver_last_name']); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Requested Items -->
        <div class="card">
            <div class="card-header">
                <h3>Requested Items</h3>
            </div>
            <div class="card-body">
                <?php if (empty($request_items)): ?>
                    <p>No items found for this request.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Item Code</th>
                                    <th>Item Name</th>
                                    <th>Description</th>
                                    <th>Quantity Requested</th>
                                    <th>Quantity Returned</th>
                                    <th>Status</th>
                                    <th>Issued Date</th>
                                    <th>Returned Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($request_items as $item): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['item_code']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                    <td><small><?php echo htmlspecialchars($item['description'] ?: 'No description'); ?></small></td>
                                    <td><?php echo $item['quantity_requested']; ?></td>
                                    <td><?php echo $item['quantity_returned'] ?: '0'; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($item['item_status']); ?>">
                                            <?php echo $item['item_status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $item['issued_date'] ? formatDateTime($item['issued_date']) : '-'; ?></td>
                                    <td><?php echo $item['returned_date'] ? formatDateTime($item['returned_date']) : '-'; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Request Timeline -->
        <div class="card">
            <div class="card-header">
                <h3>Request Timeline</h3>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-date"><?php echo formatDateTime($request['created_at']); ?></div>
                        <div class="timeline-content">
                            <strong>Request Submitted</strong><br>
                            Request created by <?php echo htmlspecialchars($request['requester_first_name'] . ' ' . $request['requester_last_name']); ?>
                        </div>
                    </div>
                    
                    <?php if ($request['status'] != 'Pending'): ?>
                    <div class="timeline-item">
                        <div class="timeline-date"><?php echo formatDateTime($request['created_at']); ?></div>
                        <div class="timeline-content">
                            <strong>Request <?php echo $request['status']; ?></strong><br>
                            <?php if ($request['approved_by']): ?>
                                Action taken by <?php echo htmlspecialchars($request['approver_first_name'] . ' ' . $request['approver_last_name']); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($request['return_date']): ?>
                    <div class="timeline-item">
                        <div class="timeline-date"><?php echo formatDateTime($request['return_date']); ?></div>
                        <div class="timeline-content">
                            <strong>Items Returned</strong><br>
                            All borrowed items have been returned to the system
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Reject Request</h3>
                <span class="close" onclick="closeRejectModal()">&times;</span>
            </div>
            <form method="POST" id="rejectForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reject">
                    <div class="form-group">
                        <label for="reason">Reason for rejection:</label>
                        <textarea id="reason" name="reason" rows="4" required placeholder="Please provide a reason for rejecting this request..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject Request</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showRejectModal() {
            document.getElementById('rejectModal').style.display = 'block';
        }

        function closeRejectModal() {
            document.getElementById('rejectModal').style.display = 'none';
            document.getElementById('reason').value = '';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('rejectModal');
            if (event.target == modal) {
                closeRejectModal();
            }
        }
    </script>
</body>
</html>
