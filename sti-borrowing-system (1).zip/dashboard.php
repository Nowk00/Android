<?php
require_once 'config/functions.php';
requireLogin();

$user_info = getUserInfo($_SESSION['user_id']);
$user_type = getUserType();

// Get date range from query parameters (default to last 6 months)
$date_from = $_GET['date_from'] ?? date('Y-m-d', strtotime('-6 months'));
$date_to = $_GET['date_to'] ?? date('Y-m-d');

// Get dashboard statistics
try {
    // Total requests
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM borrowing_requests WHERE archived = FALSE");
    $stmt->execute();
    $total_requests = $stmt->fetchColumn();
    
    // Pending requests
    $stmt = $pdo->prepare("SELECT COUNT(*) as pending FROM borrowing_requests WHERE status = 'Pending' AND archived = FALSE");
    $stmt->execute();
    $pending_requests = $stmt->fetchColumn();
    
    // Approved requests
    $stmt = $pdo->prepare("SELECT COUNT(*) as approved FROM borrowing_requests WHERE status = 'Approved' AND archived = FALSE");
    $stmt->execute();
    $approved_requests = $stmt->fetchColumn();
    
    // Completed requests
    $stmt = $pdo->prepare("SELECT COUNT(*) as completed FROM borrowing_requests WHERE status IN ('Completed', 'Returned') AND archived = FALSE");
    $stmt->execute();
    $completed_requests = $stmt->fetchColumn();
    
    // Total items
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM items WHERE archived = FALSE");
    $stmt->execute();
    $total_items = $stmt->fetchColumn();
    
    // Available items
    $stmt = $pdo->prepare("SELECT SUM(available_quantity) as available FROM items WHERE archived = FALSE");
    $stmt->execute();
    $available_items = $stmt->fetchColumn() ?: 0;
    
    // Total users
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM users WHERE archived = FALSE");
    $stmt->execute();
    $total_users = $stmt->fetchColumn();
    
    // Monthly borrowing trends (last 6 months)
    $stmt = $pdo->prepare("
        SELECT 
            DATE_FORMAT(created_at, '%Y-%m') as month,
            COUNT(*) as request_count
        FROM borrowing_requests 
        WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) 
        AND archived = FALSE
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month ASC
    ");
    $stmt->execute();
    $monthly_trends = $stmt->fetchAll();
    
    // Request status distribution
    $stmt = $pdo->prepare("
        SELECT status, COUNT(*) as count 
        FROM borrowing_requests 
        WHERE archived = FALSE 
        GROUP BY status
    ");
    $stmt->execute();
    $status_distribution = $stmt->fetchAll();
    
    // Most borrowed items
    $stmt = $pdo->prepare("
        SELECT i.item_name, SUM(ri.quantity_requested) as total_borrowed
        FROM request_items ri
        JOIN items i ON ri.item_id = i.item_id
        JOIN borrowing_requests br ON ri.request_id = br.request_id
        WHERE br.archived = FALSE
        GROUP BY i.item_id, i.item_name
        ORDER BY total_borrowed DESC
        LIMIT 5
    ");
    $stmt->execute();
    $most_borrowed_items = $stmt->fetchAll();
    
    // User type distribution
    $stmt = $pdo->prepare("
        SELECT user_type, COUNT(*) as count 
        FROM users 
        WHERE archived = FALSE 
        GROUP BY user_type
    ");
    $stmt->execute();
    $user_type_distribution = $stmt->fetchAll();
    
    // Recent activity (last 10 activities)
    $stmt = $pdo->prepare("
        SELECT al.*, u.first_name, u.last_name 
        FROM activity_logs al
        JOIN users u ON al.user_id = u.user_id
        ORDER BY al.timestamp DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_activities = $stmt->fetchAll();
    
    // Recent requests
    if ($user_type == 'Borrower') {
        $stmt = $pdo->prepare("
            SELECT br.*, u.first_name, u.last_name 
            FROM borrowing_requests br 
            JOIN users u ON br.requester_id = u.user_id 
            WHERE br.requester_id = ? AND br.archived = FALSE 
            ORDER BY br.created_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$_SESSION['user_id']]);
    } else {
        $stmt = $pdo->prepare("
            SELECT br.*, u.first_name, u.last_name 
            FROM borrowing_requests br 
            JOIN users u ON br.requester_id = u.user_id 
            WHERE br.archived = FALSE 
            ORDER BY br.created_at DESC 
            LIMIT 5
        ");
        $stmt->execute();
    }
    $recent_requests = $stmt->fetchAll();
    
} catch(PDOException $e) {
    $total_requests = $pending_requests = $approved_requests = $completed_requests = 0;
    $total_items = $available_items = $total_users = 0;
    $monthly_trends = $status_distribution = $most_borrowed_items = [];
    $user_type_distribution = $recent_activities = $recent_requests = [];
}

// Prepare data for charts
$months = [];
$request_counts = [];
foreach ($monthly_trends as $trend) {
    $months[] = date('M Y', strtotime($trend['month'] . '-01'));
    $request_counts[] = $trend['request_count'];
}

$status_labels = [];
$status_counts = [];
$status_colors = [];
$color_map = [
    'Pending' => '#ffc107',
    'Approved' => '#28a745', 
    'Rejected' => '#dc3545',
    'Completed' => '#17a2b8',
    'Returned' => '#6c757d'
];
foreach ($status_distribution as $status) {
    $status_labels[] = $status['status'];
    $status_counts[] = $status['count'];
    $status_colors[] = $color_map[$status['status']] ?? '#6c757d';
}

$item_names = [];
$item_counts = [];
foreach ($most_borrowed_items as $item) {
    $item_names[] = $item['item_name'];
    $item_counts[] = $item['total_borrowed'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - STI Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .chart-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        
        .chart-header {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .chart-header h3 {
            margin: 0;
            color: #2c3e50;
            font-size: 16px;
        }
        
        .chart-canvas {
            position: relative;
            height: 300px;
        }
        
        .activity-feed {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #667eea;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-time {
            font-size: 12px;
            color: #666;
        }
        
        .stats-enhanced {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .filter-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: end;
        }
        
        @media (max-width: 768px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }
        }
    </style>
</head>
<body class="dashboard">
    <header class="header">
        <div class="header-content">
            <div class="header-left">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <div class="header-title">
                    <h1>STI Borrowing System</h1>
                    <p>Equipment & Resource Management</p>
                </div>
            </div>
            <div class="header-right">
                <div class="user-info">
                    <div class="user-name"><?php echo htmlspecialchars($user_info['first_name'] . ' ' . $user_info['last_name']); ?></div>
                    <div class="user-role"><?php echo htmlspecialchars($user_info['user_type']); ?></div>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <nav class="nav">
        <div class="nav-content">
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <?php if ($user_type == 'Borrower'): ?>
                    <li><a href="create-request.php">Create Request</a></li>
                    <li><a href="my-requests.php">My Requests</a></li>
                <?php endif; ?>
                <?php if (in_array($user_type, ['Custodian', 'Administrator'])): ?>
                    <li><a href="manage-requests.php">Manage Requests</a></li>
                    <li><a href="manage-items.php">Manage Items</a></li>
                <?php endif; ?>
                <?php if ($user_type == 'Administrator'): ?>
                    <li><a href="manage-users.php">Manage Users</a></li>
                    <li><a href="reports.php">Reports</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>

    <main class="main-content">
        <div class="page-header">
            <h1>Dashboard</h1>
            <p>Welcome back, <?php echo htmlspecialchars($user_info['first_name']); ?>! Here's an overview of the system.</p>
        </div>

        <!-- Enhanced Statistics Cards -->
        <div class="stats-enhanced">
            <div class="stat-card">
                <div class="stat-number"><?php echo $total_requests; ?></div>
                <div class="stat-label">Total Requests</div>
            </div>
            <div class="stat-card pending">
                <div class="stat-number"><?php echo $pending_requests; ?></div>
                <div class="stat-label">Pending Requests</div>
            </div>
            <div class="stat-card approved">
                <div class="stat-number"><?php echo $approved_requests; ?></div>
                <div class="stat-label">Approved Requests</div>
            </div>
            <div class="stat-card items">
                <div class="stat-number"><?php echo $available_items; ?>/<?php echo $total_items; ?></div>
                <div class="stat-label">Available Items</div>
            </div>
            <?php if (in_array($user_type, ['Administrator', 'Custodian'])): ?>
            <div class="stat-card users">
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Charts and Graphs -->
        <div class="charts-grid">
            <!-- Monthly Trends Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3>📈 Monthly Borrowing Trends</h3>
                </div>
                <div class="chart-canvas">
                    <canvas id="monthlyTrendsChart"></canvas>
                </div>
            </div>

            <!-- Status Distribution Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3>📊 Request Status Distribution</h3>
                </div>
                <div class="chart-canvas">
                    <canvas id="statusChart"></canvas>
                </div>
            </div>

            <!-- Most Borrowed Items -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3>🏆 Most Borrowed Items</h3>
                </div>
                <div class="chart-canvas">
                    <canvas id="itemsChart"></canvas>
                </div>
            </div>

            <!-- Recent Activity Feed -->
            <?php if (in_array($user_type, ['Administrator', 'Custodian'])): ?>
            <div class="chart-container">
                <div class="chart-header">
                    <h3>🔔 Recent Activity</h3>
                </div>
                <div class="activity-feed">
                    <?php if (empty($recent_activities)): ?>
                        <p>No recent activity.</p>
                    <?php else: ?>
                        <?php foreach ($recent_activities as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon"></div>
                            <div class="activity-content">
                                <div><?php echo htmlspecialchars($activity['description']); ?></div>
                                <div class="activity-time">
                                    <?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?> • 
                                    <?php echo formatDateTime($activity['timestamp']); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Recent Requests Table -->
        <div class="card">
            <div class="card-header">
                <h3>Recent Borrowing Requests</h3>
            </div>
            <div class="card-body">
                <?php if (empty($recent_requests)): ?>
                    <p>No recent requests found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Request ID</th>
                                    <th>Requester</th>
                                    <th>Subject</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_requests as $request): ?>
                                <tr>
                                    <td>#<?php echo str_pad($request['request_id'], 4, '0', STR_PAD_LEFT); ?></td>
                                    <td><?php echo htmlspecialchars($request['first_name'] . ' ' . $request['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['subject']); ?></td>
                                    <td><?php echo formatDate($request['created_at']); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($request['status']); ?>">
                                            <?php echo $request['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="view-request.php?id=<?php echo $request['request_id']; ?>" class="btn btn-info btn-sm">View</a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <?php if ($user_type == 'Borrower'): ?>
                    <a href="my-requests.php" class="btn btn-primary">View All My Requests</a>
                <?php else: ?>
                    <a href="manage-requests.php" class="btn btn-primary">Manage All Requests</a>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <script>
        // Monthly Trends Chart
        const monthlyCtx = document.getElementById('monthlyTrendsChart').getContext('2d');
        new Chart(monthlyCtx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($months); ?>,
                datasets: [{
                    label: 'Borrowing Requests',
                    data: <?php echo json_encode($request_counts); ?>,
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Status Distribution Chart
        const statusCtx = document.getElementById('statusChart').getContext('2d');
        new Chart(statusCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($status_labels); ?>,
                datasets: [{
                    data: <?php echo json_encode($status_counts); ?>,
                    backgroundColor: <?php echo json_encode($status_colors); ?>,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Most Borrowed Items Chart
        const itemsCtx = document.getElementById('itemsChart').getContext('2d');
        new Chart(itemsCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($item_names); ?>,
                datasets: [{
                    label: 'Times Borrowed',
                    data: <?php echo json_encode($item_counts); ?>,
                    backgroundColor: [
                        '#667eea',
                        '#764ba2', 
                        '#f093fb',
                        '#f5576c',
                        '#4facfe'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
