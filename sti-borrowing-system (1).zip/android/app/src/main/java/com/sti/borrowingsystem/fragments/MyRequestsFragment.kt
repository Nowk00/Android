package com.sti.borrowingsystem.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.sti.borrowingsystem.CreateRequestActivity
import com.sti.borrowingsystem.RequestDetailActivity
import com.sti.borrowingsystem.adapters.MyRequestsAdapter
import com.sti.borrowingsystem.api.ApiClient
import com.sti.borrowingsystem.databinding.FragmentMyRequestsBinding
import com.sti.borrowingsystem.models.BorrowingRequest
import com.sti.borrowingsystem.utils.SessionManager
import kotlinx.coroutines.launch

class MyRequestsFragment : Fragment() {
    
    private var _binding: FragmentMyRequestsBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var sessionManager: SessionManager
    private lateinit var requestsAdapter: MyRequestsAdapter
    private var allRequests = listOf<BorrowingRequest>()
    private var currentFilter = "All"
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyRequestsBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        sessionManager = SessionManager(requireContext())
        setupUI()
        setupRecyclerView()
        setupTabs()
        setupSwipeRefresh()
        loadRequests()
    }
    
    private fun setupUI() {
        binding.fabCreateRequest.setOnClickListener {
            startActivityForResult(Intent(context, CreateRequestActivity::class.java), REQUEST_CREATE)
        }
    }
    
    private fun setupRecyclerView() {
        requestsAdapter = MyRequestsAdapter { request ->
            val intent = Intent(context, RequestDetailActivity::class.java)
            intent.putExtra("request_id", request.request_id)
            startActivity(intent)
        }
        
        binding.rvRequests.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = requestsAdapter
        }
    }
    
    private fun setupTabs() {
        val tabs = listOf("All", "Pending", "Approved", "Released", "Returned", "Rejected")
        
        tabs.forEach { status ->
            binding.tabLayout.addTab(binding.tabLayout.newTab().setText(status))
        }
        
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                currentFilter = tab?.text.toString()
                filterRequests()
            }
            
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            loadRequests()
        }
    }
    
    fun refreshData() {
        loadRequests()
    }
    
    private fun loadRequests() {
        val token = sessionManager.getAuthHeader()
        if (token == null) {
            Toast.makeText(context, "Authentication error", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val response = ApiClient.requestService.getRequests(token)
                
                if (response.success) {
                    allRequests = response.data
                    filterRequests()
                } else {
                    Toast.makeText(context, response.message, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load requests: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun filterRequests() {
        val filteredRequests = if (currentFilter == "All") {
            allRequests
        } else {
            allRequests.filter { it.status.equals(currentFilter, ignoreCase = true) }
        }
        
        requestsAdapter.updateRequests(filteredRequests)
        
        // Show/hide empty state
        if (filteredRequests.isEmpty()) {
            binding.tvEmptyRequests.visibility = View.VISIBLE
            binding.rvRequests.visibility = View.GONE
            
            binding.tvEmptyRequests.text = when (currentFilter) {
                "All" -> "No requests found.\nCreate your first borrowing request!"
                else -> "No $currentFilter requests found."
            }
        } else {
            binding.tvEmptyRequests.visibility = View.GONE
            binding.rvRequests.visibility = View.VISIBLE
        }
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CREATE && resultCode == android.app.Activity.RESULT_OK) {
            loadRequests()
        }
    }
    
    override fun onResume() {
        super.onResume()
        loadRequests()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    
    companion object {
        private const val REQUEST_CREATE = 1001
    }
}
