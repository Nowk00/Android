<?php
require_once 'config/functions.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_number = sanitizeInput($_POST['id_number']);
    $password = $_POST['password'];
    
    if (empty($id_number) || empty($password)) {
        $error_message = 'Please fill in all fields.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id_number = ? AND archived = FALSE");
            $stmt->execute([$id_number]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['first_name'] = $user['first_name'];
                $_SESSION['last_name'] = $user['last_name'];
                
                // Log the login activity
                logActivity($user['user_id'], 'Login', 'User logged in successfully');
                
                header("Location: dashboard.php");
                exit();
            } else {
                $error_message = 'Invalid ID number or password.';
            }
        } catch(PDOException $e) {
            $error_message = 'Login failed. Please try again.';
            error_log("Login error: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STI College Balagtas - Borrowing System</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-box">
            <div class="login-header">
                <img src="assets/images/sti-logo.png" alt="STI Logo" class="logo">
                <h1>STI College Balagtas</h1>
                <h2>Borrowing Request System</h2>
            </div>
            
            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" class="login-form">
                <div class="form-group">
                    <label for="id_number">ID Number:</label>
                    <input type="text" id="id_number" name="id_number" required 
                           value="<?php echo isset($_POST['id_number']) ? htmlspecialchars($_POST['id_number']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-login">Login</button>
            </form>
            
            <div class="login-footer">
                <p>Default Login Credentials:</p>
                <div class="credentials">
                    <p><strong>Administrator:</strong> ADMIN001 / password</p>
                    <p><strong>Custodian:</strong> CUST001 / password</p>
                    <p><strong>Student:</strong> STU001 / password</p>
                </div>
                <div class="register-link">
                    <p>Don't have an account? <a href="register.php">Register here</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
